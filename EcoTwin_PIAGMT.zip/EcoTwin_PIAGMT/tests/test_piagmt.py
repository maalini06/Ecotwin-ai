"""PI-AGMT specifics: physics baseline, multi-building cube, what-if scoring, external scoring."""
import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.modeling import build_X, predict_rows, train_models
from core.pi_agmt import FACTORS, evaluate_frame, layout, physics_weights


def make_campus(days=140, buildings=("B01", "B02", "B03"), seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    for d in pd.date_range("2025-01-01", periods=days):
        for i, b in enumerate(buildings):
            kwh = rng.uniform(50, 150) * (1 + 0.3 * i) * (0.7 if d.dayofweek >= 5 else 1)
            diesel = rng.uniform(0, 3)
            water = rng.uniform(500, 1500)
            rows.append({"Date": d, "Building_ID": b, "Total_Electricity_kWh": kwh,
                         "Generator_Fuel_L": diesel, "Water_Consumption_L": water,
                         "CO2": kwh * 0.71 + diesel * 2.68 + water * 0.00035})
    df = pd.DataFrame(rows)
    df["Total_CO2_kg"] = df.pop("CO2")
    df["Next_Day_CO2_kg"] = df.groupby("Building_ID")["Total_CO2_kg"].shift(-1)
    return df.dropna().reset_index(drop=True)


@pytest.fixture(scope="module")
def campus():
    df = make_campus()
    meta = {"date_col": "Date", "group_col": "Building_ID", "target": "Total_CO2_kg",
            "features": ["Total_Electricity_kWh", "Generator_Fuel_L", "Water_Consumption_L"],
            "categoricals": [], "unit": "kg CO2", "name": "t", "epochs": 12}
    return df, meta, train_models(df, meta)


def test_physics_uses_standard_factors():
    cols = ["Total_Electricity_kWh", "AC_Electricity_kWh", "Generator_Fuel_L", "Bus_Diesel_L",
            "Water_Consumption_L", "Drinking_Water_L", "Total_Waste_kg", "E_Waste_kg", "Number_of_Vehicles"]
    w, b, mode, matched = physics_weights("Next_Day_CO2_kg", cols, np.zeros((2, 9)), np.zeros(2))
    assert mode == "standard emission factors" and b == 0.0
    assert w[0] == FACTORS["electricity"] and w[1] == 0 and w[2] == FACTORS["generator"]
    assert w[3] == FACTORS["bus"] and w[4] == FACTORS["water"] and w[5] == 0
    assert w[6] == FACTORS["waste"] and w[7] == 0 and w[8] == FACTORS["vehicles"]


def test_layout_is_building_by_date(campus):
    df, meta, _ = campus
    lay = layout(df, meta)
    assert lay["N"] == 3 and lay["T"] == df.Date.nunique() and lay["dropped_dates"] == 0


def test_multi_building_training(campus):
    df, meta, b = campus
    assert b["nodes"] == ["B01", "B02", "B03"]
    assert b["results"]["PI-AGMT"]["R2"] > 0.8
    assert len(b["fitted_all"]) == len(df)
    assert b["attention"]["matrix"].shape == (3, 3)
    assert set(b["baselines"]) == {"Persistence (previous day)", "Physics only (no learning)"}
    assert abs(b["importance"].sum() - 100) < 1e-6
    assert b["importance"].index[0] == "Total_Electricity_kWh"


def test_split_date_is_respected(campus):
    df, meta, _ = campus
    split = pd.Timestamp("2025-04-01")
    b = train_models(df, {**meta, "split_date": split, "epochs": 4})
    assert b["dates"]["test_start"] == split
    assert b["dates"]["train_end"] == split - pd.Timedelta(days=1)
    assert b["train_size"] == (df.Date < split).sum() and b["test_size"] == (df.Date >= split).sum()


def test_whatif_reacts_to_electricity(campus):
    df, meta, b = campus
    base = df.iloc[[-1]].copy()
    lower = base.copy()
    lower["Total_Electricity_kWh"] *= 0.5
    p0, p1 = predict_rows(b, base, meta)[0], predict_rows(b, lower, meta)[0]
    assert p1 < p0


def test_external_scoring_does_not_refit(campus):
    df, meta, b = campus
    other = make_campus(days=60, seed=5)
    r = evaluate_frame(b, other, meta, other["Total_CO2_kg"].values)
    assert r["scored_dates"] > 40 and r["model"]["R2"] > 0.5
    assert "Persistence (previous day)" in r["baselines"] and r["notes"] == []


def test_external_survives_schema_drift(campus):
    df, meta, b = campus
    other = make_campus(days=60, seed=7).drop(columns=["Water_Consumption_L", "Generator_Fuel_L"])
    r = evaluate_frame(b, other, meta, other["Total_CO2_kg"].values)
    assert set(r["missing_columns"]) == {"Water_Consumption_L", "Generator_Fuel_L"}
    assert r["model"] is not None and np.isfinite(r["predictions"]).all()


def test_external_with_missing_and_unseen_buildings(campus):
    df, meta, b = campus
    other = make_campus(days=60, buildings=("B01", "B02"), seed=8)
    r = evaluate_frame(b, other, meta, other["Total_CO2_kg"].values)
    assert r["absent_buildings"] == ["B03"] and r["model"] is not None


def test_external_without_target_gives_predictions_only(campus):
    df, meta, b = campus
    other = make_campus(days=30, seed=9)
    r = evaluate_frame(b, other, meta, None)
    assert r["model"] is None and np.isfinite(r["predictions"]).all()


def test_external_with_too_few_dates_does_not_crash(campus):
    df, meta, b = campus
    other = make_campus(days=4, seed=10)
    r = evaluate_frame(b, other, meta, other["Total_CO2_kg"].values)
    assert r["model"] is None and len(r["predictions"]) == len(other)
