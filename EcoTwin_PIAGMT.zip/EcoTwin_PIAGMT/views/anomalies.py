"""Page 4: anomaly detection against model expectation or rolling statistics."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from core.analytics import detect_anomalies
from views.ui import ctx, fmt, page_header, plot


def render():
    df, meta, bundle, q = ctx()
    page_header("warning", "Anomalies", "Records that deviate unusually from expectation")

    c1, c2 = st.columns([2, 1])
    method = c1.radio("Detection method", ["Model residual", "Rolling statistic"], horizontal=True)
    z = c2.slider("Sensitivity (z-score)", 1.5, 4.0, 2.5, 0.1)

    a = detect_anomalies(df, meta, bundle, method, z)
    flagged = a[a["Anomaly"]]
    c = st.columns(3)
    c[0].metric("Flagged records", len(flagged))
    c[1].metric("Share of dataset", f"{len(flagged) / len(a) * 100:.1f}%")
    c[2].metric("Strongest deviation", f"{a['Score'].abs().max():.1f} sigma" if len(a) else "-")

    x = a["Date"] if meta["date_col"] else a.index
    fig = go.Figure()
    fig.add_scatter(x=x, y=a["Actual"], mode="lines", name="Actual", line=dict(color="#8B7CF6", width=1.6))
    fig.add_scatter(x=x, y=a["Expected"], mode="lines", name="Expected", line=dict(color="#38BDF8", width=1.4, dash="dot"))
    if len(flagged):
        fx = flagged["Date"] if meta["date_col"] else flagged.index
        fig.add_scatter(x=fx, y=flagged["Actual"], mode="markers", name="Anomaly",
                        marker=dict(color="#FB7185", size=9, symbol="diamond"))
    plot(fig, height=420)

    if len(flagged):
        st.markdown("#### Flagged records")
        show = flagged.sort_values("Score", key=abs, ascending=False).head(25).copy()
        show["Score"] = show["Score"].round(2)
        st.dataframe(show[["Date", "Actual", "Expected", "Score", "Direction"]] if meta["date_col"]
                    else show[["Actual", "Expected", "Score", "Direction"]], width="stretch", height=340)
    else:
        st.success("No anomalies at this sensitivity.")
