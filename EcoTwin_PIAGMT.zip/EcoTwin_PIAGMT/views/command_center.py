"""Command Center: a quick-glance status hub with shortcuts into the rest of the app."""
from __future__ import annotations

import streamlit as st

from core.analytics import kpis, risk_level
from views.ui import badge, ctx, fmt, page_header

TONE = {"Low": "good", "Medium": "warn", "High": "bad"}

SHORTCUTS = [
    ("Overview", "dashboard", "KPIs, trend and model performance"),
    ("Forecast", "timeline", "Project the target forward"),
    ("Anomalies", "warning", "Unusual records at a glance"),
    ("Risk & Budget", "shield", "Composite risk and budget pace"),
    ("Carbon Dependency Graph", "hub", "Where emissions flow from"),
    ("What-if Simulator", "tune", "Test activity-level changes"),
    ("Scenario Comparison", "compare_arrows", "Compare saved scenarios"),
    ("Roadmap", "route", "Phased reduction plan"),
    ("Recommendations & Tracking", "fact_check", "Generate and track actions"),
    ("Reports", "description", "Export a summary"),
    ("Daily Emission Calculator", "calculate", "Manual activity-based estimate"),
]


def render():
    df, meta, bundle, q = ctx()
    page_header("space_dashboard", "Command Center", f"{meta['name']} · everything at a glance")

    k = kpis(df, meta)
    r = risk_level(df, meta)
    tone = {"good": "#38BDF8", "warn": "#F5B942", "bad": "#FB7185"}[TONE[r["level"]]]

    c = st.columns(4)
    c[0].metric("Total_CO2_kg", fmt(k["total"], meta["unit"]))
    c[1].metric("Recent trend", f"{k['change_pct']:+.1f}%")
    c[2].metric("Model", bundle["best"])
    with c[3]:
        st.markdown(f"<div style='padding-top:6px'><span class='muted' style='text-transform:uppercase;"
                    f"font-size:.82rem'>Risk level</span><br>"
                    f"<span class='badge' style='background:{tone}22;color:{tone};border:1px solid {tone}55'>"
                    f"{r['level']}</span></div>", unsafe_allow_html=True)

    st.divider()
    st.markdown("#### Jump to a module")
    cols = st.columns(3)
    for i, (label, icon, desc) in enumerate(SHORTCUTS):
        with cols[i % 3]:
            st.markdown(f"<div class='card' style='margin-bottom:12px'><h4>:material/{icon}: {label}</h4>"
                        f"<div class='muted'>{desc}</div></div>", unsafe_allow_html=True)
            if st.button("Open", key=f"cc_{label}", width="stretch", icon=":material/arrow_forward:"):
                st.session_state["nav"] = label
                st.rerun()
