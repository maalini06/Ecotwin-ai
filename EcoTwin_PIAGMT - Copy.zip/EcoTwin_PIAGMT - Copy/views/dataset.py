"""
Page 1: Sona Campus dataset intake.

Configured specifically for the PI-AGMT campus carbon model.

Expected dataset:
    Sona_Campus_train.csv
    Sona_Campus_validation.csv
    DatasetB.csv

Target:
    Next_Day_CO2_kg

The Sona dataset contains:
    45 total columns
    40 numeric columns
    39 numeric input features
    1 numeric target
"""

from __future__ import annotations

import os

import pandas as pd
import streamlit as st

from core.data import (
    DatasetError,
    add_co2_change_columns,
    clean_data,
    quality_report,
    read_upload,
)

from core.modeling import train_models

from views.ui import (
    badge,
    page_header,
)


# ============================================================
# PROJECT PATHS
# ============================================================

ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

SAMPLE = os.path.join(
    ROOT,
    "sample_data",
    "EcoTwin_AI_Computer_Lab_1000.csv"
)


# ============================================================
# SONA CAMPUS CONFIGURATION
# ============================================================

SONA_DATE = "Date"

SONA_TARGET = "Next_Day_CO2_kg"

SONA_GROUP = "Building_ID"


# ============================================================
# CATEGORICAL COLUMNS
# ============================================================

SONA_CATEGORICALS = [
    "Academic_Term"
]


# ============================================================
# COLUMNS NOT USED AS NUMERIC FEATURES
# ============================================================

SONA_EXCLUDED = [
    "Date",
    "Building_ID",
    "Building_Name",
    "Department",
    "Academic_Term",
    "Next_Day_CO2_kg",
]


# ============================================================
# SESSION STATE
# ============================================================

STATE_KEYS = [
    "raw",
    "raw_name",
    "raw_sig",
    "ready",
    "df",
    "meta",
    "clean_log",
    "quality",
    "bundle",
    "_fc",
    "_fc_key",
    "scenarios",
    "goto_landing",
    "whatif_result",
    "rec_table",
    "rec_tracked",
]


# ============================================================
# RESET WORKSPACE
# ============================================================

def reset_workspace():

    for k in STATE_KEYS:

        st.session_state.pop(
            k,
            None
        )

    for k in list(
        st.session_state
    ):

        if k.startswith(
            (
                "sim_",
                "map_",
                "calc_",
                "track_",
                "effort_",
            )
        ):

            st.session_state.pop(
                k,
                None
            )


# ============================================================
# LOAD RAW DATA
# ============================================================

def _load_raw(
    df: pd.DataFrame,
    name: str,
    sig
):

    reset_workspace()

    st.session_state.update(
        raw=df,
        raw_name=name,
        raw_sig=sig
    )


# ============================================================
# PAGE RENDER
# ============================================================

def render():

    if st.session_state.get(
        "ready"
    ):

        _loaded_view()

    else:

        _intake_view()


# ============================================================
# DATASET UPLOAD PAGE
# ============================================================

def _intake_view():

    st.markdown(
        '<div class="hero">'
        '<h1>Bring your data, build your twin</h1>'
        '<p>'
        'Upload the Sona Campus carbon dataset. '
        'PI-AGMT uses Next_Day_CO2_kg as the forecasting target '
        'and automatically selects the correct numeric campus '
        'features.'
        '</p>'
        '</div>',
        unsafe_allow_html=True
    )

    left, right = st.columns(
        [3, 2],
        gap="large"
    )

    # --------------------------------------------------------
    # UPLOAD
    # --------------------------------------------------------

    with left:

        up = st.file_uploader(
            "Upload a CSV or Excel file",
            type=[
                "csv",
                "xlsx",
                "xls"
            ],
            help=(
                "Upload Sona_Campus_train.csv, "
                "Sona_Campus_validation.csv, "
                "DatasetB.csv, or the combined Sona dataset."
            )
        )

    # --------------------------------------------------------
    # INFORMATION CARD
    # --------------------------------------------------------

    with right:

        st.markdown(
            "<div class='card'>"
            "<h4>Sona Campus PI-AGMT dataset</h4>"

            "<div class='step'>"
            "<div class='n'>1</div>"
            "<div class='muted'>"
            "Date column: <b>Date</b>"
            "</div>"
            "</div>"

            "<div class='step'>"
            "<div class='n'>2</div>"
            "<div class='muted'>"
            "Building column: <b>Building_ID</b>"
            "</div>"
            "</div>"

            "<div class='step'>"
            "<div class='n'>3</div>"
            "<div class='muted'>"
            "Prediction target: <b>Next_Day_CO2_kg</b>"
            "</div>"
            "</div>"

            "<div class='step'>"
            "<div class='n'>4</div>"
            "<div class='muted'>"
            "39 numeric input features"
            "</div>"
            "</div>"

            "</div>",
            unsafe_allow_html=True
        )

    # --------------------------------------------------------
    # UPLOADED FILE
    # --------------------------------------------------------

    if up is not None:

        sig = (
            up.name,
            up.size
        )

        if (
            st.session_state.get(
                "raw_sig"
            )
            != sig
        ):

            try:

                df = read_upload(
                    up,
                    up.name
                )

                _load_raw(
                    df,
                    up.name,
                    sig
                )

            except DatasetError as exc:

                st.error(
                    str(exc)
                )

                return

    # --------------------------------------------------------
    # DEMO DATASET
    # --------------------------------------------------------

    else:

        if os.path.exists(
            SAMPLE
        ):

            if st.button(
                "Try the bundled demo dataset",
                icon=":material/science:",
                type="secondary"
            ):

                _load_raw(
                    read_upload(
                        SAMPLE,
                        "demo.csv"
                    ),
                    "demo dataset (computer lab)",
                    ("demo",)
                )

                st.rerun()

    # --------------------------------------------------------
    # GET RAW DATA
    # --------------------------------------------------------

    raw = st.session_state.get(
        "raw"
    )

    if raw is None:

        return

    _configure(
        raw
    )


# ============================================================
# DATASET CONFIGURATION
# ============================================================

def _configure(
    raw: pd.DataFrame
):

    sig = str(
        st.session_state[
            "raw_sig"
        ]
    )

    # --------------------------------------------------------
    # CLEAN COLUMN NAMES
    # --------------------------------------------------------

    raw = raw.copy()

    raw.columns = [
        str(c).strip()
        for c in raw.columns
    ]

    # --------------------------------------------------------
    # CHECK WHETHER THIS IS SONA DATA
    # --------------------------------------------------------

    is_sona = (
        SONA_DATE in raw.columns
        and
        SONA_TARGET in raw.columns
        and
        SONA_GROUP in raw.columns
    )

    # ========================================================
    # SONA DATASET
    # ========================================================

    if is_sona:

        _configure_sona(
            raw,
            sig
        )

        return

    # ========================================================
    # NON-SONA DATASET
    # ========================================================

    _configure_generic(
        raw,
        sig
    )


# ============================================================
# SONA-SPECIFIC CONFIGURATION
# ============================================================

def _configure_sona(
    raw: pd.DataFrame,
    sig: str
):

    st.divider()

    st.markdown(
        f"### :material/tune: Configure "
        f"{badge(st.session_state['raw_name'], 'info')}",
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # DATASET INFORMATION
    # --------------------------------------------------------

    st.caption(
        f"{len(raw):,} rows and "
        f"{raw.shape[1]} columns detected."
    )

    # --------------------------------------------------------
    # FORCE SONA ROLES
    # --------------------------------------------------------

    date_sel = SONA_DATE

    target = SONA_TARGET

    grp_sel = SONA_GROUP

    unit = "kg CO2"

    cats = [
        c
        for c in SONA_CATEGORICALS
        if c in raw.columns
    ]

    # --------------------------------------------------------
    # NUMERIC FEATURES
    # --------------------------------------------------------

    features = []

    for c in raw.columns:

        if c in SONA_EXCLUDED:

            continue

        if pd.api.types.is_numeric_dtype(
            raw[c]
        ):

            features.append(
                c
            )

    # --------------------------------------------------------
    # DISPLAY EXACT COUNT
    # --------------------------------------------------------

    st.success(
        f"Sona Campus schema detected: "
        f"{len(raw.columns)} total columns | "
        f"{len(features)} numeric model features | "
        f"target: {target}"
    )

    # --------------------------------------------------------
    # CONFIGURATION TABLE
    # --------------------------------------------------------

    c1, c2, c3, c4 = st.columns(4)

    c1.metric(
        "Total columns",
        len(raw.columns)
    )

    c2.metric(
        "Numeric features",
        len(features)
    )

    c3.metric(
        "Target",
        target
    )

    c4.metric(
        "Building column",
        grp_sel
    )

    # --------------------------------------------------------
    # SHOW FEATURE LIST
    # --------------------------------------------------------

    with st.expander(
        f"PI-AGMT feature columns ({len(features)})",
        expanded=False
    ):

        feature_df = pd.DataFrame(
            {
                "No.": range(
                    1,
                    len(features) + 1
                ),
                "Feature": features
            }
        )

        st.dataframe(
            feature_df,
            width="stretch",
            hide_index=True,
            height=350
        )

    # --------------------------------------------------------
    # TARGET INFORMATION
    # --------------------------------------------------------

    st.info(
        f"Model target: **{target}**"
    )

    st.caption(
        "The target is not counted as a feature. "
        "Date, Building_ID, Building_Name, Department "
        "and Academic_Term are also excluded from the "
        "numeric feature count."
    )

    # --------------------------------------------------------
    # VALIDATION DATE
    # --------------------------------------------------------

    split_txt = st.text_input(
        "Validation starts on (YYYY-MM-DD, optional)",
        value="",
        key=f"map_split_{sig}",
        help=(
            "Leave empty for the project's automatic "
            "chronological validation split."
        )
    )

    # --------------------------------------------------------
    # NEGATIVE VALUE HANDLING
    # --------------------------------------------------------

    clip = st.checkbox(
        "Treat negative values as invalid and clip them to zero",
        value=False,
        key=f"map_clip_{sig}"
    )

    # --------------------------------------------------------
    # PREVIEW
    # --------------------------------------------------------

    with st.expander(
        "Preview of uploaded data",
        expanded=True
    ):

        st.dataframe(
            raw.head(50),
            width="stretch",
            height=260
        )

    # --------------------------------------------------------
    # BUILD WORKSPACE
    # --------------------------------------------------------

    ok = st.button(
        "Build workspace",
        type="primary",
        icon=":material/rocket_launch:"
    )

    if not ok:

        return

    # --------------------------------------------------------
    # VALIDATE TARGET
    # --------------------------------------------------------

    if target not in raw.columns:

        st.error(
            f"Required target "
            f"'{target}' is missing."
        )

        return

    # --------------------------------------------------------
    # VALIDATE FEATURES
    # --------------------------------------------------------

    if not features:

        st.error(
            "No numeric PI-AGMT features were detected."
        )

        return

    # --------------------------------------------------------
    # VALIDATE DATE
    # --------------------------------------------------------

    split_date = None

    if split_txt.strip():

        split_date = pd.to_datetime(
            split_txt.strip(),
            errors="coerce"
        )

        if pd.isna(
            split_date
        ):

            st.error(
                "Enter the validation start "
                "as YYYY-MM-DD."
            )

            return

    # --------------------------------------------------------
    # BUILD META
    # --------------------------------------------------------

    meta = {
        "date_col": date_sel,
        "target": target,
        "group_col": grp_sel,
        "split_date": split_date,
        "features": features,
        "categoricals": cats,
        "unit": unit,
        "name": st.session_state[
            "raw_name"
        ],
    }

    # --------------------------------------------------------
    # TRAIN
    # --------------------------------------------------------

    try:

        with st.spinner(
            "Cleaning data and training PI-AGMT "
            "(this can take a minute or two)..."
        ):

            df, log = clean_data(
                raw,
                meta,
                clip
            )

            quality = quality_report(
                raw,
                df,
                meta
            )

            bundle = train_models(
                df,
                meta
            )

    except (
        DatasetError,
        ValueError
    ) as exc:

        st.error(
            str(exc)
        )

        return

    # --------------------------------------------------------
    # SAVE WORKSPACE
    # --------------------------------------------------------

    st.session_state.update(
        ready=True,
        df=df,
        meta=meta,
        clean_log=log,
        quality=quality,
        bundle=bundle,
        ds_id=(
            st.session_state.get(
                "ds_id",
                0
            )
            + 1
        ),
        scenarios=[],
        goto_landing=True
    )

    st.rerun()


# ============================================================
# GENERIC DATASET CONFIGURATION
# ============================================================

def _configure_generic(
    raw: pd.DataFrame,
    sig: str
):

    """
    Fallback configuration for datasets that are
    not Sona Campus datasets.

    This keeps the application usable for other
    datasets while Sona datasets use the fixed
    PI-AGMT configuration above.
    """

    from core.data import detect_schema

    guess = detect_schema(
        raw
    )

    st.divider()

    st.markdown(
        f"### :material/tune: Configure "
        f"{badge(st.session_state['raw_name'], 'info')}",
        unsafe_allow_html=True
    )

    st.caption(
        f"{len(raw):,} rows and "
        f"{raw.shape[1]} columns detected."
    )

    cols = list(
        raw.columns
    )

    # --------------------------------------------------------
    # DATE
    # --------------------------------------------------------

    c1, c2, c3 = st.columns(3)

    date_opts = [
        "(none)"
    ] + cols

    date_sel = c1.selectbox(
        "Date column",
        date_opts,
        index=(
            date_opts.index(
                guess["date_col"]
            )
            if guess["date_col"]
            else 0
        ),
        key=f"map_date_{sig}"
    )

    # --------------------------------------------------------
    # TARGET
    # --------------------------------------------------------

    num_like = [
        c
        for c in cols
        if c != date_sel
    ]

    tgt_default = (
        guess["target"]
        if guess["target"] in num_like
        else num_like[0]
    )

    target = c2.selectbox(
        "Target to predict",
        num_like,
        index=num_like.index(
            tgt_default
        ),
        key=f"map_target_{sig}"
    )

    # --------------------------------------------------------
    # UNIT
    # --------------------------------------------------------

    unit = c3.text_input(
        "Unit label",
        value=guess["unit"],
        key=f"map_unit_{sig}"
    )

    # --------------------------------------------------------
    # GROUP
    # --------------------------------------------------------

    g1, g2 = st.columns(2)

    grp_opts = [
        "(none)"
    ] + [
        c
        for c in cols
        if c not in (
            date_sel,
            target
        )
    ]

    grp_sel = g1.selectbox(
        "Building / entity column (optional)",
        grp_opts,
        index=(
            grp_opts.index(
                guess["group_col"]
            )
            if guess.get(
                "group_col"
            ) in grp_opts
            else 0
        ),
        key=f"map_group_{sig}"
    )

    split_txt = g2.text_input(
        "Validation starts on (YYYY-MM-DD, optional)",
        value="",
        key=f"map_split_{sig}"
    )

    # --------------------------------------------------------
    # FEATURES
    # --------------------------------------------------------

    feat_pool = [
        c
        for c in cols
        if c not in (
            date_sel,
            target,
            grp_sel
        )
    ]

    feat_default = [
        c
        for c in guess["features"]
        if c in feat_pool
    ]

    features = st.multiselect(
        "Feature columns (numeric drivers)",
        feat_pool,
        default=feat_default,
        key=f"map_feat_{sig}"
    )

    # --------------------------------------------------------
    # CATEGORIES
    # --------------------------------------------------------

    cat_pool = [
        c
        for c in feat_pool
        if c not in features
    ]

    cat_default = [
        c
        for c in guess["categoricals"]
        if c in cat_pool
    ]

    cats = st.multiselect(
        "Category columns (optional)",
        cat_pool,
        default=cat_default,
        key=f"map_cat_{sig}"
    )

    # --------------------------------------------------------
    # CLIP
    # --------------------------------------------------------

    clip = st.checkbox(
        "Treat negative values as invalid and clip them to zero",
        value=False,
        key=f"map_clip_{sig}"
    )

    # --------------------------------------------------------
    # PREVIEW
    # --------------------------------------------------------

    with st.expander(
        "Preview of uploaded data",
        expanded=True
    ):

        st.dataframe(
            raw.head(50),
            width="stretch",
            height=260
        )

    # --------------------------------------------------------
    # BUILD
    # --------------------------------------------------------

    ok = st.button(
        "Build workspace",
        type="primary",
        icon=":material/rocket_launch:"
    )

    if not ok:

        return

    if (
        not features
        and date_sel == "(none)"
    ):

        st.error(
            "Select at least one feature column "
            "or a date column."
        )

        return

    split_date = None

    if split_txt.strip():

        split_date = pd.to_datetime(
            split_txt.strip(),
            errors="coerce"
        )

        if (
            pd.isna(split_date)
            or date_sel == "(none)"
        ):

            st.error(
                "Enter the validation start "
                "as YYYY-MM-DD and select "
                "a date column."
            )

            return

    meta = {
        "date_col": (
            None
            if date_sel == "(none)"
            else date_sel
        ),
        "target": target,
        "group_col": (
            None
            if grp_sel == "(none)"
            else grp_sel
        ),
        "split_date": split_date,
        "features": features,
        "categoricals": cats,
        "unit": unit or "units",
        "name": st.session_state[
            "raw_name"
        ],
    }

    try:

        with st.spinner(
            "Cleaning data and training PI-AGMT..."
        ):

            df, log = clean_data(
                raw,
                meta,
                clip
            )

            quality = quality_report(
                raw,
                df,
                meta
            )

            bundle = train_models(
                df,
                meta
            )

    except (
        DatasetError,
        ValueError
    ) as exc:

        st.error(
            str(exc)
        )

        return

    st.session_state.update(
        ready=True,
        df=df,
        meta=meta,
        clean_log=log,
        quality=quality,
        bundle=bundle,
        ds_id=(
            st.session_state.get(
                "ds_id",
                0
            )
            + 1
        ),
        scenarios=[],
        goto_landing=True
    )

    st.rerun()


# ============================================================
# LOADED WORKSPACE
# ============================================================

def _loaded_view():

    s = st.session_state

    df = s["df"]

    meta = s["meta"]

    q = s["quality"]

    bundle = s["bundle"]

    # --------------------------------------------------------
    # HEADER
    # --------------------------------------------------------

    st.markdown(
        f'<div class="hero">'
        f'<h1>Workspace ready</h1>'
        f'<p>'
        f'{meta["name"]} is loaded and every module '
        f'now runs on it. '
        f'Target: <b>{meta["target"]}</b> '
        f'({meta["unit"]}).'
        f'</p>'
        f'</div>',
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # MAIN METRICS
    # --------------------------------------------------------

    m = st.columns(4)

    m[0].metric(
        "Records",
        f"{q['rows']:,}"
    )

    m[1].metric(
        "Feature columns",
        len(meta["features"])
    )

    m[2].metric(
        "Model",
        bundle["best"]
    )

    m[3].metric(
        "Held-out R2",
        f"{bundle['results'][bundle['best']]['R2']:.3f}"
    )

    # --------------------------------------------------------
    # MODEL DATE INFORMATION
    # --------------------------------------------------------

    d = bundle.get(
        "dates"
    ) or {}

    if d.get(
        "test_start"
    ) is not None:

        st.caption(
            f"Trained up to "
            f"{d['train_end']:%d %b %Y}; "
            f"held-out validation from "
            f"{d['test_start']:%d %b %Y}. "
            f"{len(bundle['nodes'])} building(s)/entities, "
            f"physics prior: "
            f"{bundle['physics']['mode']}."
        )

        if d.get(
            "dropped_incomplete_dates"
        ):

            st.warning(
                f"{d['dropped_incomplete_dates']} "
                f"date(s) were skipped by the model "
                f"because some buildings had no record."
            )

    # --------------------------------------------------------
    # DATE RANGE
    # --------------------------------------------------------

    if q["date_range"]:

        a, b = q["date_range"]

        st.markdown(
            f"<span class='chip'>"
            f"{a:%d %b %Y} to "
            f"{b:%d %b %Y}"
            f"</span>"
            f"<span class='chip'>"
            f"{q['freq_label']} records"
            f"</span>",
            unsafe_allow_html=True
        )

    # --------------------------------------------------------
    # LEAKAGE
    # --------------------------------------------------------

    if q["leakage"]:

        st.warning(
            "These features are almost perfectly "
            "correlated with the target and may leak it: "
            + ", ".join(
                q["leakage"]
            )
            + ". Predictions can look better "
              "than they really are."
        )

    # --------------------------------------------------------
    # TABS
    # --------------------------------------------------------

    t1, t2, t3 = st.tabs(
        [
            "Data quality",
            "Cleaning log",
            "Cleaned data"
        ]
    )

    # ========================================================
    # DATA QUALITY
    # ========================================================

    with t1:

        a, b, c, d = st.columns(4)

        a.metric(
            "Missing cells (raw)",
            q["missing_cells"]
        )

        b.metric(
            "Duplicate rows (raw)",
            q["duplicates"]
        )

        c.metric(
            "Columns with outliers",
            len(q["outliers"])
        )

        d.metric(
            "Constant columns",
            len(q["constant_cols"])
        )

        if q["outliers"]:

            st.caption(
                "Extreme values (beyond 3x IQR): "
                + ", ".join(
                    f"{k} ({v})"
                    for k, v
                    in q["outliers"].items()
                )
            )

        if q["negatives"]:

            st.caption(
                "Negative values present: "
                + ", ".join(
                    f"{k} ({v})"
                    for k, v
                    in q["negatives"].items()
                )
            )

        cw = q[
            "corr_with_target"
        ]

        if len(cw):

            st.bar_chart(
                cw.head(12),
                horizontal=True,
                color="#8B7CF6",
                height=300
            )

            st.caption(
                "Correlation of each feature "
                "with the target."
            )

    # ========================================================
    # CLEANING LOG
    # ========================================================

    with t2:

        for line in s[
            "clean_log"
        ]:

            st.markdown(
                f"- {line}"
            )

    # ========================================================
    # CLEANED DATA
    # ========================================================

    with t3:

        shown = add_co2_change_columns(df)

        st.dataframe(
            shown,
            width="stretch",
            height=380
        )

        st.download_button(
            "Download cleaned data",
            shown.to_csv(
                index=False
            ).encode(),
            "cleaned_data.csv",
            "text/csv",
            icon=":material/download:"
        )

    # --------------------------------------------------------
    # LOAD DIFFERENT DATASET
    # --------------------------------------------------------

    st.divider()

    if st.button(
        "Load a different dataset",
        icon=":material/upload_file:"
    ):

        reset_workspace()

        st.rerun()