"""PI-AGMT: Physics-Informed Adaptive Graph-Mamba Transformer.

final = physics baseline (activity x standard emission factor)
      + residual learned by  [feature embedding -> Mamba-style selective state-space block over the
                              last WINDOW days -> attention across buildings (adaptive graph)]

Data layout: rows (date, building) are arranged into a cube  (T dates, N buildings, F features).
The module is independent of Streamlit and of core.modeling (the caller passes the feature matrix).
The Mamba block is a compact pure-PyTorch selective SSM (no CUDA kernel needed, runs on CPU).
"""
from __future__ import annotations

import copy

import numpy as np
import pandas as pd

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as Fn
except ImportError:  # pragma: no cover
    torch = None

from core.emission_calc import ACTIVITIES

WINDOW = 7
TEST_FRACTION = 0.2
FACTORS = {a["key"]: a["factor"] for a in ACTIVITIES}

# key, name fragments to look for (priority order), name tokens to avoid
_RULES = [
    ("electricity", ("total_electricity", "electricity_kwh", "electricity"),
     {"co2", "solar", "grid", "generator", "next", "day", "per", "person", "ac", "lighting", "light",
      "fan", "computer", "equipment", "other", "renewable", "pct", "percentage"}),
    ("generator", ("generator_fuel", "generator_diesel"), {"co2", "next", "per", "person"}),
    ("bus", ("bus_diesel",), {"co2", "next", "per", "person"}),
    ("vehicles", ("number_of_vehicles", "vehicles"), {"co2", "next", "per", "person"}),
    ("water", ("water_consumption", "water_l", "water"),
     {"co2", "drinking", "restroom", "cleaning", "canteen", "recycling", "next", "per", "person"}),
    ("waste", ("total_waste", "waste_kg", "waste"),
     {"co2", "food", "paper", "plastic", "e", "recycled", "landfill", "next", "per", "person"}),
]


def _check_torch():
    if torch is None:
        raise ImportError("PyTorch is required for PI-AGMT. Install it with:  pip install torch")


def metrics(y, p) -> dict:
    y, p = np.asarray(y, float).ravel(), np.asarray(p, float).ravel()
    err = y - p
    ss_tot = float(((y - y.mean()) ** 2).sum())
    denom = np.where(np.abs(y) < 1e-9, np.nan, np.abs(y))
    return {"MAE": float(np.abs(err).mean()), "RMSE": float(np.sqrt((err ** 2).mean())),
            "R2": float(1 - (err ** 2).sum() / ss_tot) if ss_tot > 0 else 0.0,
            "MAPE": float(np.nanmean(np.abs(err) / denom) * 100)}


# ------------------------------------------------------------------ physics baseline
def _pick(cols, includes, avoid):
    for frag in includes:
        for c in cols:
            lc = c.lower()
            if frag in lc and not (set(lc.split("_")) & avoid):
                return c
    return None


def physics_weights(target: str, cols: list[str], Xtr: np.ndarray, ytr: np.ndarray):
    """Linear physics prior  phys = X @ w + b.
    Emission datasets: standard factors on the matching activity columns (no fitting).
    Anything else: a non-negative linear fit on training rows (learned prior)."""
    base_idx = [i for i, c in enumerate(cols) if not c.startswith(("cal_", "cat_"))]
    base_cols = [cols[i] for i in base_idx]
    w = np.zeros(len(cols))
    matched = {}
    if any(k in target.lower() for k in ("co2", "emission", "carbon")):
        for key, inc, avoid in _RULES:
            c = _pick(base_cols, inc, avoid)
            if c:
                w[cols.index(c)] = FACTORS[key]
                matched[key] = c
    if matched:
        return w, 0.0, "standard emission factors", matched
    from sklearn.linear_model import LinearRegression
    m = LinearRegression(positive=True).fit(Xtr[:, base_idx], ytr)
    w[base_idx] = m.coef_
    return w, float(m.intercept_), "learned non-negative linear prior", {}


# ------------------------------------------------------------------ data cube
def layout(df: pd.DataFrame, meta: dict, labels: list[str] | None = None, partial: bool = False) -> dict:
    """Map every row to (date index, building index). Training needs complete dates (all buildings present);
    partial=True (scoring unseen data) keeps any date that has at least one building."""
    dcol, gcol = meta.get("date_col"), meta.get("group_col")
    if dcol and dcol in df.columns:
        dates = pd.to_datetime(df[dcol]).to_numpy()
    else:
        dates = np.arange(len(df))
    if gcol and gcol in df.columns:
        nodes = df[gcol].astype(str).to_numpy()
    else:
        nodes = pd.Series(dates).groupby(dates).cumcount().astype(str).to_numpy()
    lab = labels if labels is not None else sorted(set(nodes))
    pos = {l: i for i, l in enumerate(lab)}
    unknown = sorted(set(nodes) - set(pos))
    if unknown:
        raise ValueError(f"Unknown building/entity values for this model: {unknown[:5]}")
    ni = np.array([pos[x] for x in nodes])
    ud = np.unique(dates)
    di = np.searchsorted(ud, dates)
    have = np.zeros((len(ud), len(lab)), bool)
    have[di, ni] = True
    full = have.any(1) if partial else have.all(1)
    new_idx = np.full(len(ud), -1)
    new_idx[full] = np.arange(full.sum())
    return {"row_t": new_idx[di], "row_n": ni, "T": int(full.sum()), "N": len(lab), "labels": list(lab),
            "dates": ud[full], "dropped_dates": int((~full).sum()), "have": have[full]}


def _cube(lay, X, y=None):
    sel = lay["row_t"] >= 0
    Xc = np.zeros((lay["T"], lay["N"], X.shape[1]), np.float32)
    Xc[lay["row_t"][sel], lay["row_n"][sel]] = X[sel]
    Yc = None
    if y is not None:
        Yc = np.full((lay["T"], lay["N"]), np.nan, np.float32)
        Yc[lay["row_t"][sel], lay["row_n"][sel]] = y[sel]
    return Xc, Yc


# ------------------------------------------------------------------ network
if torch is not None:

    class SelectiveSSM(nn.Module):
        """Compact Mamba-style selective state-space block (input-dependent step size, B and C)."""

        def __init__(self, d: int, n: int = 16):
            super().__init__()
            self.inp = nn.Linear(d, 2 * d)
            self.dt = nn.Linear(d, d)
            self.B = nn.Linear(d, n)
            self.C = nn.Linear(d, n)
            self.A_log = nn.Parameter(torch.log(torch.arange(1, n + 1).float()).repeat(d, 1))
            self.D = nn.Parameter(torch.ones(d))
            self.out = nn.Linear(d, d)

        def forward(self, u):                                   # (B, L, d)
            x, z = self.inp(u).chunk(2, -1)
            x = Fn.silu(x)
            dt = Fn.softplus(self.dt(x))
            A = -torch.exp(self.A_log)                          # (d, n)
            Bm, Cm = self.B(x), self.C(x)                       # (B, L, n)
            h = u.new_zeros(u.size(0), u.size(2), A.size(1))
            ys = []
            for t in range(u.size(1)):
                dA = torch.exp(dt[:, t].unsqueeze(-1) * A)
                dB = dt[:, t].unsqueeze(-1) * Bm[:, t].unsqueeze(1)
                h = dA * h + dB * x[:, t].unsqueeze(-1)
                ys.append((h * Cm[:, t].unsqueeze(1)).sum(-1) + self.D * x[:, t])
            return self.out(torch.stack(ys, 1) * Fn.silu(z))

    class PIAGMT(nn.Module):
        def __init__(self, n_feat, n_nodes, sd, d=48, heads=4, use_graph=True, use_temporal=True):
            super().__init__()
            self.sd, self.use_graph, self.use_temporal = float(sd), use_graph, use_temporal
            self.embed = nn.Sequential(nn.Linear(n_feat, d), nn.GELU(), nn.Dropout(0.1))
            self.node = nn.Embedding(n_nodes, d)
            self.ssm, self.norm1 = SelectiveSSM(d), nn.LayerNorm(d)
            self.attn, self.norm2 = nn.MultiheadAttention(d, heads, batch_first=True), nn.LayerNorm(d)
            self.head = nn.Sequential(nn.Linear(d, d), nn.GELU(), nn.Linear(d, 1))
            nn.init.zeros_(self.head[-1].weight)                # starts out as the pure physics baseline
            nn.init.zeros_(self.head[-1].bias)

        def forward(self, x, phys):                             # x (B,W,N,F)  phys (B,N)
            B, W, N, _ = x.shape
            h = self.embed(x) + self.node.weight                # (B,W,N,d)
            last = h[:, -1]
            if self.use_temporal:
                seq = self.ssm(h.permute(0, 2, 1, 3).reshape(B * N, W, -1))
                h = self.norm1(seq[:, -1] + last.reshape(B * N, -1)).view(B, N, -1)
            else:
                h = last
            att = None
            if self.use_graph and N > 1:
                g, att = self.attn(h, h, h, need_weights=True)
                h = self.norm2(h + g)
            return phys + self.head(h).squeeze(-1) * self.sd, att


# ------------------------------------------------------------------ predictor object
class Predictor:
    """Everything needed to score new data with a trained network."""

    def __init__(self, model, mu, sg, wphys, bphys, labels, columns, ctx_raw, window, fill):
        self.model, self.mu, self.sg, self.fill = model, mu, sg, fill
        self.wphys, self.bphys = wphys, bphys
        self.labels, self.columns, self.ctx_raw, self.window = labels, columns, ctx_raw, window

    def _scale(self, Xc):
        return torch.from_numpy(np.clip((Xc - self.mu) / self.sg, -8, 8).astype(np.float32))

    def phys(self, Xc):
        return (Xc @ self.wphys + self.bphys).astype(np.float32)

    def predict_cube(self, Xc, ts, want_att=False):
        """Predictions (len(ts), N) for the date indices ts of a raw cube."""
        self.model.eval()
        Xs, P = self._scale(Xc), torch.from_numpy(self.phys(Xc))
        W, out, atts = self.window, [], []
        with torch.no_grad():
            for i in range(0, len(ts), 64):
                t = np.asarray(ts[i:i + 64])
                idx = np.clip(t[:, None] - (W - 1) + np.arange(W)[None, :], 0, None)
                p, a = self.model(Xs[torch.from_numpy(idx)], P[torch.from_numpy(t)])
                out.append(p.numpy())
                if want_att and a is not None:
                    atts.append(a.numpy())
        att = np.concatenate(atts).mean(0) if atts else None
        return (np.concatenate(out), att) if want_att else np.concatenate(out)

    def predict_rows(self, X_rows: np.ndarray, node_idx: np.ndarray) -> np.ndarray:
        """What-if scoring: each row replaces one building on the most recent day, past days come
        from the stored history of the training data."""
        W = self.window
        base = self.ctx_raw[-W:].copy()
        out = []
        for x, n in zip(X_rows, node_idx):
            cube = base.copy()
            cube[-1, int(n)] = x
            out.append(self.predict_cube(cube, np.array([W - 1]))[0, int(n)])
        return np.asarray(out, float)


# ------------------------------------------------------------------ training
def train_piagmt(df: pd.DataFrame, meta: dict, X: pd.DataFrame, y, *, split_date=None,
                 use_physics: bool = True, use_graph: bool = True, use_temporal: bool = True,
                 epochs: int | None = None, patience: int = 8, seed: int = 42, d: int = 48,
                 importance: bool = True, verbose: bool = False) -> dict:
    _check_torch()
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    W = WINDOW
    epochs = int(epochs or meta.get("epochs") or 60)
    cols = list(X.columns)
    Xr, yv = X.to_numpy(float), np.asarray(y, float)

    lay = layout(df, meta)
    T, N = lay["T"], lay["N"]
    Xc, Yc = _cube(lay, Xr, yv)

    if split_date is not None and meta.get("date_col"):
        Tcut = int((lay["dates"] < np.datetime64(pd.Timestamp(split_date))).sum())
    else:
        Tcut = int(T * (1 - TEST_FRACTION))
    if Tcut < W + 20 or T - Tcut < 5:
        raise ValueError(f"Not enough dates for a train/test split ({T} complete dates, "
                         f"training would have {Tcut}). Need at least {W + 25}.")
    nv = max(int(Tcut * 0.1), 5)
    tr_d, es_d, te_d = np.arange(0, Tcut - nv), np.arange(Tcut - nv, Tcut), np.arange(Tcut, T)

    Xtr_flat, ytr_flat = Xc[:Tcut].reshape(-1, len(cols)), Yc[:Tcut].reshape(-1)
    if use_physics:
        wph, bph, pmode, matched = physics_weights(meta["target"], cols, Xtr_flat, ytr_flat)
    else:
        wph, bph, pmode, matched = np.zeros(len(cols)), float(ytr_flat.mean()), "none (ablation)", {}
    P = (Xc @ wph + bph).astype(np.float32)
    sd = float((Yc[:Tcut] - P[:Tcut]).std()) or 1.0
    sd = sd if sd > 1e-6 else 1.0

    mu = Xtr_flat.mean(0)
    sg = Xtr_flat.std(0)
    sg[sg < 1e-8] = 1.0

    model = PIAGMT(len(cols), N, sd, d=d, use_graph=use_graph, use_temporal=use_temporal)
    pred_ = Predictor(model, mu, sg, wph, bph, lay["labels"], cols, Xc[-W:].copy(), W,
                      np.median(Xtr_flat, 0))
    Xs, Pt, Yt = pred_._scale(Xc), torch.from_numpy(P), torch.from_numpy(Yc)
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-4)

    def window(ts):
        idx = np.clip(np.asarray(ts)[:, None] - (W - 1) + np.arange(W)[None, :], 0, None)
        return Xs[torch.from_numpy(idx)]

    def loss_on(ts):
        model.eval()
        with torch.no_grad():
            p, _ = model(window(ts), Pt[torch.from_numpy(np.asarray(ts))])
            return float((((p - Yt[torch.from_numpy(np.asarray(ts))]) / sd) ** 2).mean())

    best, best_state, bad = np.inf, None, 0
    for ep in range(epochs):
        model.train()
        order = rng.permutation(tr_d)
        for i in range(0, len(order), 32):
            ts = order[i:i + 32]
            p, _ = model(window(ts), Pt[torch.from_numpy(ts)])
            loss = (((p - Yt[torch.from_numpy(ts)]) / sd) ** 2).mean()
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        v = loss_on(es_d)
        if verbose:
            print(f"  epoch {ep + 1:3d}  val-loss {v:.4f}")
        if v < best - 1e-5:
            best, best_state, bad = v, copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
            if bad >= patience:
                break
    model.load_state_dict(best_state)

    allp = pred_.predict_cube(Xc, np.arange(T))
    _, att = pred_.predict_cube(Xc, te_d, want_att=True)
    yte, pte = Yc[te_d], allp[te_d]
    res = metrics(yte, pte)

    persist = metrics(Yc[te_d], Yc[te_d - 1])
    phys_only = metrics(yte, P[te_d])
    baselines = {"Persistence (previous day)": persist}
    if use_physics:
        baselines["Physics only (no learning)"] = phys_only

    sel = lay["row_t"] >= 0
    fitted = Xr @ wph + bph
    fitted[sel] = allp[lay["row_t"][sel], lay["row_n"][sel]]
    in_test = sel & (lay["row_t"] >= Tcut)
    dcol = meta.get("date_col")
    test_frame = pd.DataFrame({
        "Date": df[dcol].to_numpy()[in_test] if dcol else np.where(in_test)[0],
        "Actual": yv[in_test], "Predicted": fitted[in_test]})
    gcol = meta.get("group_col")
    if gcol and gcol in df.columns:
        test_frame.insert(1, "Building", df[gcol].to_numpy()[in_test])

    imp = _importance(pred_, Xc, Yc, te_d, rng) if importance else np.ones(len(cols))
    imp = pd.Series(imp, index=cols).sort_values(ascending=False)
    imp_pct = imp / imp.sum() * 100 if imp.sum() > 0 else imp

    return {
        "best": "PI-AGMT", "results": {"PI-AGMT": res}, "baselines": baselines, "model": pred_,
        "columns": cols, "importance": imp_pct, "test_frame": test_frame,
        "train_size": int((sel & (lay["row_t"] < Tcut)).sum()), "test_size": int(in_test.sum()),
        "fitted_all": fitted, "resid_std": float(np.std(yv[sel] - fitted[sel])) or 1.0,
        "attention": ({"labels": lay["labels"], "matrix": att} if att is not None else None),
        "physics": {"mode": pmode, "matched": matched}, "nodes": lay["labels"],
        "dates": {"train_end": pd.Timestamp(lay["dates"][Tcut - 1]) if dcol else None,
                  "test_start": pd.Timestamp(lay["dates"][Tcut]) if dcol else None,
                  "dropped_incomplete_dates": lay["dropped_dates"]},
        "flags": {"physics": use_physics, "graph": use_graph, "temporal": use_temporal},
    }


def _importance(pred_, Xc, Yc, te_d, rng, repeats: int = 2, max_dates: int = 120) -> np.ndarray:
    """Permutation importance of the whole pipeline (physics term + network) on held-out dates."""
    ts = te_d if len(te_d) <= max_dates else te_d[np.linspace(0, len(te_d) - 1, max_dates).astype(int)]
    y = Yc[ts]
    base = np.sqrt(((pred_.predict_cube(Xc, ts) - y) ** 2).mean())
    F = Xc.shape[2]
    out = np.zeros(F)
    block = Xc[te_d[0]:te_d[-1] + 1]
    flat = block.reshape(-1, F)
    for j in range(F):
        if np.ptp(flat[:, j]) == 0:
            continue
        gains = []
        for _ in range(repeats):
            Xp = Xc.copy()
            shuffled = flat.copy()
            shuffled[:, j] = rng.permutation(flat[:, j])
            Xp[te_d[0]:te_d[-1] + 1] = shuffled.reshape(block.shape)
            gains.append(np.sqrt(((pred_.predict_cube(Xp, ts) - y) ** 2).mean()) - base)
        out[j] = max(float(np.mean(gains)), 0.0)
    return out


# ------------------------------------------------------------------ scoring new data
def evaluate_frame(bundle: dict, df: pd.DataFrame, meta: dict, y=None) -> dict:
    """Score an unseen dataset (e.g. Dataset B) without refitting and without crashing on schema drift.

    * feature columns the model was trained on but the file lacks  -> filled with training medians
    * buildings missing from the file                              -> filled with training medians, not scored
    * rows with a missing target                                   -> predicted but not scored
    * y=None                                                       -> predictions only, no metrics
    """
    from core.modeling import build_X
    p: Predictor = bundle["model"]
    notes = []
    X = build_X(df, meta)
    missing = [c for c in p.columns if c not in X.columns and not c.startswith("cat_")]
    X = X.reindex(columns=p.columns)
    for c in missing:
        X[c] = p.fill[p.columns.index(c)]
    X = X.fillna(pd.Series(p.fill, index=p.columns)).fillna(0.0)
    if missing:
        notes.append(f"{len(missing)} trained column(s) not in the file, filled with training medians: {missing}")

    lay = layout(df, meta, labels=p.labels, partial=True)
    have = lay["have"]
    absent = [p.labels[i] for i in range(lay["N"]) if not have[:, i].any()]
    if absent:
        notes.append(f"{len(absent)} building(s) have no records in the file and are not scored: {absent}")
    yv = np.asarray(y, float) if y is not None else np.full(len(df), np.nan)
    Xc, Yc = _cube(lay, X.to_numpy(float), yv)
    Xc[~have] = p.fill
    T = lay["T"]
    pred = p.predict_cube(Xc, np.arange(T)) if T else np.zeros((0, lay["N"]))

    row_pred = np.full(len(df), np.nan)
    sel = lay["row_t"] >= 0
    row_pred[sel] = pred[lay["row_t"][sel], lay["row_n"][sel]]

    out = {"predictions": row_pred, "notes": notes, "missing_columns": missing, "absent_buildings": absent,
           "dates": int(T), "model": None, "baselines": {}, "scored_cells": 0}
    M = have & np.isfinite(Yc)
    if T <= WINDOW or not M.any():
        if y is not None:
            notes.append(f"Not enough dated records with a known target to score (need more than {WINDOW} dates).")
        return out
    keep = np.arange(WINDOW, T)
    Yz = np.nan_to_num(Yc)
    m_now = M[keep]
    if m_now.any():
        out["model"] = metrics(Yz[keep][m_now], pred[keep][m_now])
        out["scored_cells"] = int(m_now.sum())
        out["scored_dates"] = int(m_now.any(1).sum())
        m_prev = m_now & M[keep - 1]
        if m_prev.any():
            out["baselines"]["Persistence (previous day)"] = metrics(Yz[keep][m_prev], Yz[keep - 1][m_prev])
        if bundle["flags"]["physics"]:
            out["baselines"]["Physics only (no learning)"] = metrics(Yz[keep][m_now], p.phys(Xc)[keep][m_now])
    return out
