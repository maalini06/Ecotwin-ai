"""Page 8: report — consolidated summary suitable for exporting or presenting."""
from __future__ import annotations

from datetime import datetime

import streamlit as st

from core.analytics import budget_status, detect_anomalies, insights, kpis, risk_level
from views.ui import ctx, fmt, get_forecast, page_header


def render():
    df, meta, bundle, q = ctx()
    page_header("description", "Report", "Consolidated summary for export or presentation")

    k = kpis(df, meta)
    a = detect_anomalies(df, meta, bundle)
    r = risk_level(df, meta, a)
    fc = get_forecast(30)
    fc = None if fc.get("error") else fc

    lines = [f"# EcoTwin AI Report", f"_Generated {datetime.now():%d %b %Y, %H:%M}_", "",
            f"**Dataset:** {meta['name']} ({q['rows']:,} records, target `{meta['target']}` in {meta['unit']})",
            "", "## Key figures",
            f"- Total {meta['target']}: {fmt(k['total'], meta['unit'])}",
            f"- Average per record: {fmt(k['mean'], meta['unit'])}",
            f"- Recent {k['window']}-record trend: {k['change_pct']:+.1f}%",
            f"- Model: {bundle['best']} (R2 {bundle['results'][bundle['best']]['R2']:.3f})",
            f"- Anomalies flagged: {int(a['Anomaly'].sum())} of {len(a)} records",
            f"- Risk level: {r['level']}", ""]
    if fc:
        lines += [f"- 30-period forecast outlook: {fc['change_pct']:+.1f}% vs. recent level", ""]
    lines += ["## Insights"] + [f"- {x}" for x in insights(df, meta, bundle, r, fc)]
    lines += ["", "## Top drivers"] + [f"- {i}: {v:.1f}%" for i, v in bundle["importance"].head(6).items()]
    if meta["date_col"]:
        try:
            b = budget_status(df, meta, float(df[meta["target"]].tail(30).sum()))
            lines += ["", "## Budget pace", f"- {b['month']}: {fmt(b['used'], meta['unit'])} used, "
                     f"projected {fmt(b['projected'], meta['unit'])}"]
        except Exception:
            pass
    saved = st.session_state.get("scenarios", [])
    if saved:
        lines += ["", "## Saved what-if scenarios"]
        for i, s in enumerate(saved, 1):
            chg = ", ".join(f"{k} {v:+d}%" for k, v in s["changes"].items()) or "no changes"
            lines += [f"- Scenario {i} ({chg}): {s['delta']:+.1f} {meta['unit']} ({s['delta_pct']:+.1f}%)"]
    report_md = "\n".join(lines)

    st.markdown(report_md)
    st.download_button("Download report (Markdown)", report_md.encode(), "ecotwin_report.md", "text/markdown",
                       icon=":material/download:", type="primary")
