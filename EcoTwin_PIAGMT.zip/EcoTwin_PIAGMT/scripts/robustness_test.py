"""
Robustness test for PI-AGMT.

The model is trained once using:

    data/Sona_Campus_train.csv
    data/Sona_Campus_validation.csv

Then Dataset B is tested under deliberately damaged
conditions.

Dataset B:
    data/DatasetB.csv

The model is NEVER retrained on Dataset B.
"""

import contextlib
import io
import os
import sys
import types

import numpy as np
import pandas as pd


# ============================================================
# PROJECT ROOT
# ============================================================

ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

sys.path.insert(0, ROOT)

sys.path.insert(
    0,
    os.path.join(
        ROOT,
        "scripts"
    )
)


# ============================================================
# PROJECT IMPORTS
# ============================================================

import train_and_evaluate as T

from core.modeling import build_X

from core.pi_agmt import (
    evaluate_frame,
    train_piagmt,
)


# ============================================================
# LOAD TRAINING + VALIDATION
# ============================================================

# UPDATED FILE NAMES

TRAIN_FILE = os.path.join(
    ROOT,
    "data",
    "Sona_Campus_train.csv"
)

VALIDATION_FILE = os.path.join(
    ROOT,
    "data",
    "Sona_Campus_validation.csv"
)

DATASET_B_FILE = os.path.join(
    ROOT,
    "data",
    "DatasetB.csv"
)


tr = T.load(
    TRAIN_FILE
)

va = T.load(
    VALIDATION_FILE
)


# ============================================================
# ADD TOMORROW FEATURES
# ============================================================

both = T.add_tomorrow(
    pd.concat(
        [
            tr,
            va
        ],
        ignore_index=True
    )
)

train_max_date = tr.Date.max()

tr = both[
    both.Date <= train_max_date
].copy()

va = both[
    both.Date > train_max_date
].copy()


# ============================================================
# MODEL METADATA
# ============================================================

meta = T.make_meta(
    tr,
    "Sona campus"
)


# ============================================================
# TRAINING MEDIANS
# ============================================================

med = (
    tr[
        meta["features"]
    ]
    .apply(
        pd.to_numeric,
        errors="coerce"
    )
    .median()
)


# ============================================================
# PREPARE TRAIN + VALIDATION
# ============================================================

full = T.prepare(
    pd.concat(
        [
            tr,
            va
        ],
        ignore_index=True
    ),
    meta,
    med
)

meta[
    "split_date"
] = va.Date.min()


# ============================================================
# TRAIN PI-AGMT ONCE
# ============================================================

print(
    "Training PI-AGMT once..."
)

bundle = train_piagmt(
    full,
    meta,
    build_X(
        full,
        meta
    ),
    full[
        T.TARGET
    ].values,
    epochs=30,
    importance=False
)


# ============================================================
# LOAD DATASET B
# ============================================================

B = pd.read_csv(
    DATASET_B_FILE
)

B.columns = [
    str(c).strip()
    for c in B.columns
]


# ============================================================
# OUTPUT DIRECTORY
# ============================================================

out_dir = os.path.join(
    ROOT,
    "outputs"
)

tmp = os.path.join(
    out_dir,
    "_robustness_tmp"
)

os.makedirs(
    tmp,
    exist_ok=True
)


# ============================================================
# DAMAGED DATASET B
# ============================================================

garbage = B.copy()


# Numeric column converted to text
garbage[
    "Total_Electricity_kWh"
] = (
    garbage[
        "Total_Electricity_kWh"
    ]
    .astype(str)
)


# Insert invalid values
garbage.loc[
    ::7,
    "Total_Electricity_kWh"
] = "N/A"


# Insert missing values
garbage.loc[
    ::11,
    "Water_Consumption_L"
] = np.nan


# ============================================================
# ROBUSTNESS CASES
# ============================================================

CASES = {

    # 1
    "1 normal Dataset B":
        B,

    # 2
    "2 weather + solar + 6 more columns removed":
        B.drop(
            columns=[
                "Avg_Temperature_C",
                "Solar_Utilization_kWh",
                "Solar_Capacity_kWp",
                "Water_Recycling_L",
                "Public_Transport_Count",
                "Tomorrow_Holiday",
                "Tomorrow_Event_Day",
            ]
        ),

    # 3
    "3 Academic_Term removed":
        B.drop(
            columns=[
                "Academic_Term"
            ]
        ),

    # 4
    "4 tomorrow calendar flags removed":
        B.drop(
            columns=[
                "Tomorrow_Holiday",
                "Tomorrow_Event_Day",
            ]
        ),

    # 5
    "5 electricity columns removed":
        B.drop(
            columns=[
                "Total_Electricity_kWh",
                "AC_Electricity_kWh",
            ]
        ),

    # 6
    "6 target removed":
        B.drop(
            columns=[
                "Next_Day_CO2_kg"
            ]
        ),

    # 7
    "7 extra Dataset B columns retained":
        B,

    # 8
    "8 only 5 of 14 buildings":
        B[
            B.Building_ID.isin(
                [
                    "B01",
                    "B04",
                    "B07",
                    "B10",
                    "B13",
                ]
            )
        ],

    # 9
    "9 unknown building names":
        B.assign(
            Building_ID=
            B.Building_ID.replace(
                {
                    "B01": "X1",
                    "B02": "X2",
                }
            )
        ),

    # 10
    "10 shuffled rows":
        B.sample(
            frac=1,
            random_state=0
        ),

    # 11
    "11 only 5 dates":
        B[
            B.Date <= "2027-01-05"
        ],

    # 12
    "12 single date":
        B[
            B.Date == "2027-01-05"
        ],

    # 13
    "13 text and blank numeric values":
        garbage,

    # 14
    "14 extra unknown columns":
        B.assign(
            Foo=1,
            Bar="x"
        ),

    # 15
    "15 column names with spaces":
        B.rename(
            columns=lambda c:
            f" {c} "
        ),

    # 16
    "16 all-empty electricity column":
        B.assign(
            Total_Electricity_kWh=np.nan
        ),

    # 17
    "17 Date column removed":
        B.drop(
            columns=[
                "Date"
            ]
        ),

    # 18
    "18 empty file":
        B.iloc[0:0],
}


# ============================================================
# RUN ROBUSTNESS TESTS
# ============================================================

rows = []


for name, df in CASES.items():

    path = os.path.join(
        tmp,
        "case.csv"
    )

    df.to_csv(
        path,
        index=False
    )

    namespace = types.SimpleNamespace(
        external=path,
        out=tmp,
        no_tomorrow=False
    )

    buffer = io.StringIO()

    try:

        with contextlib.redirect_stdout(
            buffer
        ):

            T.run_external(
                namespace,
                bundle,
                meta,
                med,
                tr
            )

        output = buffer.getvalue()

        # ----------------------------------------------------
        # RESULTS AVAILABLE
        # ----------------------------------------------------

        result_file = os.path.join(
            tmp,
            "external_results.csv"
        )

        if (
            os.path.exists(
                result_file
            )
            and "R2" in output
        ):

            res = pd.read_csv(
                result_file
            )

            pi_rows = res[
                res.Model.str.startswith(
                    "PI-AGMT"
                )
            ]

            if len(pi_rows):

                r2 = float(
                    pi_rows[
                        "R2"
                    ].iloc[0]
                )

                status = (
                    "ran, scored"
                )

                detail = (
                    f"R2 {r2:.3f}"
                )

            else:

                status = (
                    "ran"
                )

                detail = (
                    "no PI-AGMT result"
                )

        elif (
            "predictions saved"
            in output
        ):

            status = (
                "ran, predictions only"
            )

            detail = (
                "no accuracy score possible"
            )

        elif (
            "Not enough"
            in output
        ):

            status = (
                "ran, predictions only"
            )

            detail = (
                "not enough dates for scoring"
            )

        else:

            status = (
                "stopped politely"
            )

            lines = [
                x
                for x in output.strip().splitlines()
                if x.strip()
            ]

            detail = (
                lines[-1][:100]
                if lines
                else "no rows left"
            )

    except Exception as exc:

        status = "CRASH"

        detail = (
            f"{type(exc).__name__}: "
            f"{exc}"
        )

    # --------------------------------------------------------
    # SAVE RESULT
    # --------------------------------------------------------

    rows.append(
        {
            "Test case": name,
            "Result": status,
            "Detail": detail,
        }
    )

    # --------------------------------------------------------
    # REMOVE TEMP RESULT
    # --------------------------------------------------------

    result_file = os.path.join(
        tmp,
        "external_results.csv"
    )

    if os.path.exists(
        result_file
    ):

        os.remove(
            result_file
        )

    print(
        f"{name:50s} "
        f"{status:22s} "
        f"{detail}"
    )


# ============================================================
# SAVE ROBUSTNESS REPORT
# ============================================================

robustness = pd.DataFrame(
    rows
)

robustness.to_csv(
    os.path.join(
        out_dir,
        "external_robustness.csv"
    ),
    index=False
)


# ============================================================
# CLEAN TEMP DIRECTORY
# ============================================================

for filename in os.listdir(
    tmp
):

    file_path = os.path.join(
        tmp,
        filename
    )

    if os.path.isfile(
        file_path
    ):

        os.remove(
            file_path
        )


if os.path.isdir(
    tmp
):

    os.rmdir(
        tmp
    )


# ============================================================
# FINAL RESULT
# ============================================================

crashes = sum(
    r["Result"] == "CRASH"
    for r in rows
)

print(
    "\n================================================"
)

print(
    "ROBUSTNESS TEST COMPLETE"
)

print(
    "================================================"
)

print(
    f"Crashes: "
    f"{crashes} of {len(rows)}"
)

print(
    "\nResult saved to:"
)

print(
    os.path.join(
        out_dir,
        "external_robustness.csv"
    )
)