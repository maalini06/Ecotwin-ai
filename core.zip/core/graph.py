"""Carbon Dependency Graph — builds a hub-and-spoke network (target in the
centre, one node per feature) from the dataset's own columns. Categories are
inferred from column names by keyword heuristics, so it works for any
dataset; features that match nothing fall under 'Other Activity'."""
from __future__ import annotations

import math

import pandas as pd

CATEGORY_RULES = [
    ("Backup Power", ("generator",)),
    ("Transportation", ("bus", "vehicle", "diesel", "fuel", "trip")),
    ("Water", ("water",)),
    ("Waste", ("waste",)),
    ("Solar / Renewable", ("solar", "renewable")),
    ("Electricity", ("electric", "kwh", "ac", "light", "fan", "computer", "power", "energy")),
]

PALETTE = {
    "hub": "#FB7185",
    "Electricity": "#8B7CF6",
    "Transportation": "#38BDF8",
    "Backup Power": "#F5B942",
    "Water": "#22D3EE",
    "Waste": "#FDBA74",
    "Solar / Renewable": "#F0ABFC",
    "Other Activity": "#818CF8",
}


def categorize(col: str) -> str:
    c = col.lower()
    for cat, keys in CATEGORY_RULES:
        if any(k in c for k in keys):
            return cat
    return "Other Activity"


def _rgba(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def build_network(df: pd.DataFrame, meta: dict, bundle: dict) -> dict:
    """One node per feature plus the target hub. Edge strength = |correlation|
    with the target; node size = model importance where available, else
    correlation strength. Everything needed to render + explain each node
    on click is included so the view stays presentation-only."""
    feats = [c for c in meta["features"] if c in df.columns]
    target = meta["target"]

    corr = (df[feats + [target]].corr()[target].drop(target)
           if feats else pd.Series(dtype=float)).fillna(0.0)
    imp = bundle.get("importance", pd.Series(dtype=float)) if bundle else pd.Series(dtype=float)

    nodes, edges = [], []
    nodes.append({"id": target, "label": _short(target), "title": target, "kind": "hub",
                  "category": "Target", "color": PALETTE["hub"], "size": 42})

    for c in feats:
        cat = categorize(c)
        c_imp = float(imp.get(c, 0.0))
        c_corr = float(corr.get(c, 0.0))
        strength = c_imp if c_imp > 0 else abs(c_corr) * 100
        size = 14 + min(strength, 40) * 0.7
        nodes.append({"id": c, "label": _short(c), "title": c, "kind": "feature",
                      "category": cat, "color": PALETTE.get(cat, PALETTE["Other Activity"]),
                      "size": round(size, 1), "importance": round(c_imp, 2), "corr": round(c_corr, 3)})
        edges.append({"source": c, "target": target,
                      "width": round(1 + abs(c_corr) * 6, 2),
                      "color": _rgba(PALETTE.get(cat, PALETTE["Other Activity"]), 0.55)})

    return {"target": target, "nodes": nodes, "edges": edges,
            "categories": sorted({n["category"] for n in nodes if n["kind"] == "feature"})}


def layout_positions(net: dict, radius: float = 1.0) -> dict:
    """Hub at the centre, feature nodes fanned evenly around a circle -
    the star layout in the reference design, computed with no extra
    plotting library (pure trigonometry)."""
    feats = [n for n in net["nodes"] if n["kind"] == "feature"]
    n = max(len(feats), 1)
    pos = {net["target"]: (0.0, 0.0)}
    for i, node in enumerate(feats):
        angle = -math.pi / 2 + 2 * math.pi * i / n
        pos[node["id"]] = (radius * math.cos(angle), radius * math.sin(angle))
    return pos


def bezier_curve(p0: tuple, p2: tuple, bow: float = 0.22, steps: int = 16) -> tuple[list, list]:
    """Quadratic-bezier points from p0 to p2, bowed sideways so edges fan
    out like the reference image instead of drawing as straight spokes."""
    (x0, y0), (x2, y2) = p0, p2
    dx, dy = x2 - x0, y2 - y0
    dist = math.hypot(dx, dy) or 1e-9
    px, py = -dy / dist, dx / dist  # unit perpendicular
    mx, my = (x0 + x2) / 2 + px * bow * dist, (y0 + y2) / 2 + py * bow * dist
    xs, ys = [], []
    for i in range(steps + 1):
        t = i / steps
        xs.append((1 - t) ** 2 * x0 + 2 * (1 - t) * t * mx + t ** 2 * x2)
        ys.append((1 - t) ** 2 * y0 + 2 * (1 - t) * t * my + t ** 2 * y2)
    return xs, ys


def _short(name: str, limit: int = 16) -> str:
    return name if len(name) <= limit else name[: limit - 1] + "…"


def explain_node(network: dict, node_id: str) -> dict:
    """Human-readable dependency summary for whichever node was clicked."""
    by_id = {n["id"]: n for n in network["nodes"]}
    node = by_id.get(node_id)
    if node is None:
        return {}
    if node["kind"] == "hub":
        top = sorted([n for n in network["nodes"] if n["kind"] == "feature"],
                    key=lambda n: abs(n["corr"]), reverse=True)[:5]
        return {"title": node["id"], "kind": "hub", "top_drivers": top}
    return {"title": node["id"], "kind": "feature", "category": node["category"],
            "corr": node["corr"], "importance": node["importance"], "target": network["target"]}
