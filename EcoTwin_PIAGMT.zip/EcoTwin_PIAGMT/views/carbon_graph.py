"""Carbon Dependency Graph: an interactive node-link network built with plain
Plotly (no extra packages). The target sits in the centre; every feature is
a spoke. Click a node to see how it depends on the target."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from core.graph import bezier_curve, build_network, explain_node, layout_positions
from views.ui import ctx, page_header, plot, style


def render():
    df, meta, bundle, q = ctx()
    page_header("hub", "Carbon Dependency Graph", "Click a node to see its dependency on the target")

    net = build_network(df, meta, bundle)
    pos = layout_positions(net)
    by_id = {n["id"]: n for n in net["nodes"]}

    fig = go.Figure()
    for i, e in enumerate(net["edges"]):
        xs, ys = bezier_curve(pos[e["source"]], pos[e["target"]], bow=0.22 if i % 2 == 0 else -0.22)
        fig.add_scatter(x=xs, y=ys, mode="lines", line=dict(width=e["width"], color=e["color"]),
                        hoverinfo="skip", showlegend=False)

    node_ids = [n["id"] for n in net["nodes"]]
    fig.add_scatter(
        x=[pos[i][0] for i in node_ids], y=[pos[i][1] for i in node_ids],
        mode="markers+text", text=[by_id[i]["label"] for i in node_ids],
        textposition="top center", textfont=dict(size=11, color="#C9CEEA"),
        marker=dict(size=[by_id[i]["size"] for i in node_ids],
                   color=[by_id[i]["color"] for i in node_ids],
                   line=dict(width=2, color="#0D1020")),
        customdata=node_ids,
        hovertext=[by_id[i]["title"] for i in node_ids], hoverinfo="text",
        showlegend=False)

    fig.update_xaxes(visible=False, range=[-1.6, 1.6])
    fig.update_yaxes(visible=False, range=[-1.6, 1.6], scaleanchor="x", scaleratio=1)
    fig = style(fig, height=560, legend=False)

    result = st.plotly_chart(fig, width="stretch", on_select="rerun", selection_mode="points",
                             key="cdg_chart")

    st.markdown("#### Dependency detail")
    points = (result.get("selection", {}).get("points") if result else None) or []
    clicked = points[0]["customdata"][0] if points and points[0].get("customdata") else None

    if not clicked:
        st.caption(f"Click any node above to see exactly how it depends on **{meta['target']}**.")
    else:
        info = explain_node(net, clicked)
        if info.get("kind") == "hub":
            st.markdown(f"**{info['title']}** is the target. Its strongest dependencies:")
            for d in info["top_drivers"]:
                direction = "increases" if d["corr"] >= 0 else "decreases"
                st.markdown(f"- **{d['id']}** — correlation {d['corr']:+.2f} ({direction} the target), "
                           f"model importance {d['importance']:.1f}%")
        elif info:
            direction = "rises with" if info["corr"] >= 0 else "falls as"
            st.markdown(
                f"<div class='card'><h4>{info['title']}</h4>"
                f"<span class='chip'>{info['category']}</span>"
                f"<div class='muted' style='margin-top:8px'>{info['target']} {direction} "
                f"<b>{info['title']}</b> — correlation <b>{info['corr']:+.2f}</b>, "
                f"model importance <b>{info['importance']:.1f}%</b> of predictive sensitivity.</div></div>",
                unsafe_allow_html=True)

    st.markdown("#### Categories detected in this dataset")
    cols = st.columns(min(len(net["categories"]), 4) or 1)
    for i, cat in enumerate(net["categories"]):
        feats = [n["id"] for n in net["nodes"] if n["kind"] == "feature" and n["category"] == cat]
        with cols[i % len(cols)]:
            st.markdown(f"<div class='card'><h4>{cat}</h4>"
                        f"<div class='muted'>{', '.join(feats)}</div></div>", unsafe_allow_html=True)
    st.caption("Categories are inferred from column names, and edge thickness reflects correlation "
              "strength with the target — this works for any dataset you upload.")

    att = bundle.get("attention")
    if att is not None:
        st.markdown("#### Building-to-building attention (learned by the model's graph layer)")
        hm = go.Figure(go.Heatmap(z=att["matrix"], x=att["labels"], y=att["labels"], colorscale="Viridis"))
        hm.update_yaxes(autorange="reversed")
        plot(hm, height=460, legend=False, key="att_heatmap")
        st.caption("Row = building making the prediction, column = building it pays attention to. "
                   "Brighter means stronger influence, averaged over the held-out period.")
