@echo off
REM Install dependencies only, without launching the app (Windows).
cd /d "%~dp0"
python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
echo Setup complete. Run run.bat to start the app, or:
echo   .venv\Scripts\activate ^&^& streamlit run app.py
