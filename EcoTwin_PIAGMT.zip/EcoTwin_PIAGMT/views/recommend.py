"""Page 7: recommendation roadmap — ranked reduction actions phased into Now/Next/Later."""
from __future__ import annotations

import plotly.express as px
import streamlit as st

from core.analytics import baseline_row, recommend
from core.data import adjustable_features
from views.ui import ctx, fmt, page_header, plot


def render():
    df, meta, bundle, q = ctx()
    page_header("route", "Roadmap", "Ranked actions by predicted saving per unit of effort")

    levers = adjustable_features(df, meta)
    if not levers:
        st.info("No adjustable numeric features were found for this dataset.")
        return

    c1, c2 = st.columns(2)
    step = c1.slider("Reduction to evaluate per lever", 5, 50, 15, 5, format="%d%%")
    chosen = c2.multiselect("Levers to evaluate", levers, default=levers[:8])
    if not chosen:
        st.warning("Choose at least one lever.")
        return

    base = baseline_row(df, meta, "Recent average")
    effort = {c: st.session_state.get(f"effort_{c}", 2) for c in chosen}
    with st.expander("Adjust effort weighting (1 = easy, 3 = hard)"):
        cols = st.columns(3)
        for i, c in enumerate(chosen):
            effort[c] = cols[i % 3].slider(c, 1, 3, effort.get(c, 2), key=f"effort_{c}")

    table = recommend(bundle, meta, base, chosen, step, effort)
    fig = px.bar(table.reset_index(), x="Priority score", y="Lever", color="Phase", orientation="h",
                color_discrete_map={"Now": "#8B7CF6", "Next": "#38BDF8", "Later": "#465088"})
    fig.update_yaxes(autorange="reversed")
    plot(fig, height=max(320, 40 * len(table)))

    show = table.copy()
    show["Predicted saving"] = show["Predicted saving"].round(1)
    show["Saving %"] = show["Saving %"].round(1)
    show["Priority score"] = show["Priority score"].round(2)
    st.dataframe(show, width="stretch", height=min(80 + 35 * len(show), 420))
    st.download_button("Download roadmap", show.to_csv().encode(), "roadmap.csv", "text/csv",
                       icon=":material/download:")
