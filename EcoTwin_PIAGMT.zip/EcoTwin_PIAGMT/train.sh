#!/usr/bin/env bash
# Train PI-AGMT on data/ train+validation files and write results to outputs/ (macOS / Linux).
# Extra options are passed through, e.g.  ./train.sh --external data/DatasetB.csv --epochs 40
set -e
cd "$(dirname "$0")"
[ -d ".venv" ] || python3 -m venv .venv
source .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
python scripts/train_and_evaluate.py "$@"
