#!/usr/bin/env bash
# EcoTwin AI — one-command setup + launch for macOS / Linux.
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  echo "Creating virtual environment (.venv) ..."
  python3 -m venv .venv
fi

source .venv/bin/activate
echo "Installing dependencies ..."
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

echo "Starting EcoTwin AI ..."
streamlit run app.py
