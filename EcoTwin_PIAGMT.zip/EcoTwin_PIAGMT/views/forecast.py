"""Page 3: time-series forecasting for the active target."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from views.ui import fmt, get_forecast, page_header, plot
from views.ui import ctx as _ctx


def render():
    df, meta, bundle, q = _ctx()
    page_header("timeline", "Forecast", "Projected future values with an uncertainty band")

    if not meta["date_col"]:
        st.info("Forecasting needs a date column. Reload the dataset and select one on the Dataset page.")
        return

    horizon = st.slider("Days to forecast", 7, 90, 30, step=7)
    fc = get_forecast(horizon)
    if fc.get("error"):
        st.warning(fc["error"])
        return

    m = fc["metrics"]
    c = st.columns(4)
    c[0].metric("Validation MAE", fmt(m["MAE"], meta["unit"]))
    c[1].metric("Validation R2", f"{m['R2']:.3f}")
    c[2].metric("vs. naive baseline", f"{(1 - m['RMSE'] / fc['naive']['RMSE']) * 100:+.0f}% RMSE")
    c[3].metric("Average outlook", f"{fc['change_pct']:+.1f}%")

    hist = fc["history"].iloc[-120:]
    f = fc["forecast"]
    fig = go.Figure()
    fig.add_scatter(x=hist.index, y=hist.values, name="History", line=dict(color="#8B7CF6", width=2))
    fig.add_scatter(x=f["Date"], y=f["Forecast"], name="Forecast", line=dict(color="#38BDF8", width=2, dash="dot"))
    fig.add_scatter(x=list(f["Date"]) + list(f["Date"][::-1]), y=list(f["Upper"]) + list(f["Lower"][::-1]),
                    fill="toself", fillcolor="rgba(56,189,248,0.15)", line=dict(width=0),
                    name="Uncertainty band", hoverinfo="skip")
    plot(fig, height=440)

    with st.expander("Forecast table"):
        show = f.copy()
        show[["Forecast", "Lower", "Upper"]] = show[["Forecast", "Lower", "Upper"]].round(2)
        st.dataframe(show, width="stretch", height=280)
        st.download_button("Download forecast", f.to_csv(index=False).encode(), "forecast.csv", "text/csv",
                           icon=":material/download:")
    st.caption("The band widens with distance from the last known record and reflects model uncertainty, "
              "not a guarantee.")
