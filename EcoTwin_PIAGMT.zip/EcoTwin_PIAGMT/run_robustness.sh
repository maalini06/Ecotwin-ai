#!/usr/bin/env bash
# Scores 18 deliberately damaged copies of Dataset B and proves nothing crashes.
cd "$(dirname "$0")"
python3 scripts/robustness_test.py
echo
echo "Results: outputs/external_robustness.csv"
