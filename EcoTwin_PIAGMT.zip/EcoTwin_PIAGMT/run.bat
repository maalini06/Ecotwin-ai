@echo off
REM EcoTwin AI - one-command setup + launch for Windows.
cd /d "%~dp0"

if not exist ".venv" (
  echo Creating virtual environment .venv ...
  python -m venv .venv
)

call .venv\Scripts\activate.bat
echo Installing dependencies ...
python -m pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

echo Starting EcoTwin AI ...
streamlit run app.py
