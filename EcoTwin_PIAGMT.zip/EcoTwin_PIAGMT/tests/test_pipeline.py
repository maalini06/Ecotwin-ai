"""End-to-end tests: the pipeline must work for any tabular dataset, not just the demo one."""
import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.analytics import baseline_row, budget_status, detect_anomalies, kpis, recommend, risk_level, simulate
from core.data import adjustable_features, clean_data, detect_schema, quality_report
from core.modeling import forecast_target, predict_rows, train_models

HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLE = os.path.join(os.path.dirname(HERE), "sample_data", "EcoTwin_AI_Computer_Lab_1000.csv")


@pytest.fixture(scope="module")
def demo():
    raw = pd.read_csv(SAMPLE)
    meta = detect_schema(raw)
    meta["name"] = "demo"
    df, log = clean_data(raw, meta)
    return raw, df, meta, log


@pytest.fixture(scope="module")
def bundle(demo):
    _, df, meta, _ = demo
    meta = {**meta, "epochs": 12}
    return train_models(df, meta)


@pytest.fixture(scope="module")
def generic():
    rng = np.random.default_rng(0)
    n = 150
    df = pd.DataFrame({
        "day": pd.date_range("2025-01-01", periods=n, freq="D"),
        "units": rng.integers(5, 100, n),
        "cost": rng.uniform(1, 20, n).round(2),
        "category": rng.choice(["A", "B"], n),
    })
    df["output_metric"] = df["units"] * df["cost"] + rng.normal(0, 5, n)
    return df


def test_schema_detection_demo(demo):
    raw, df, meta, log = demo
    assert meta["target"] == "Total_CO2_kg"
    assert meta["date_col"] == "Date"
    assert len(meta["features"]) > 5


def test_schema_detection_generic(generic):
    meta = detect_schema(generic)
    assert meta["target"] == "output_metric"
    assert meta["date_col"] == "day"
    assert set(["units", "cost"]).issubset(meta["features"])


def test_clean_data_no_nulls(demo):
    _, df, meta, _ = demo
    assert df[meta["target"]].isna().sum() == 0
    assert df.duplicated().sum() == 0


def test_quality_report_no_leakage(demo):
    raw, df, meta, _ = demo
    rep = quality_report(raw, df, meta)
    assert rep["leakage"] == []
    assert rep["rows"] == len(df)


def test_train_models_and_predict(demo, bundle):
    _, df, meta, _ = demo
    assert bundle["best"] == "PI-AGMT" and list(bundle["results"]) == ["PI-AGMT"]
    assert bundle["results"][bundle["best"]]["R2"] > 0.5
    preds = predict_rows(bundle, df.iloc[:5], meta)
    assert len(preds) == 5


def test_train_models_generic(generic):
    meta = detect_schema(generic)
    df, _ = clean_data(generic, meta)
    b = train_models(df, {**meta, "epochs": 12})
    assert b["results"][b["best"]]["R2"] > 0.2


def test_forecast(demo):
    _, df, meta, _ = demo
    fc = forecast_target(df, meta, horizon=14)
    assert len(fc["forecast"]) == 14
    assert set(["Forecast", "Lower", "Upper"]).issubset(fc["forecast"].columns)


def test_anomalies_both_methods(demo, bundle):
    _, df, meta, _ = demo
    a1 = detect_anomalies(df, meta, bundle, "Model residual")
    a2 = detect_anomalies(df, meta, bundle, "Rolling statistic")
    assert "Anomaly" in a1.columns and "Anomaly" in a2.columns
    assert len(a1) == len(df) == len(a2)


def test_risk_and_budget(demo, bundle):
    _, df, meta, _ = demo
    a = detect_anomalies(df, meta, bundle)
    r = risk_level(df, meta, a)
    assert r["level"] in ("Low", "Medium", "High")
    b = budget_status(df, meta, float(df[meta["target"]].tail(30).sum()))
    assert b["days_in_month"] > 0


def test_whatif_simulation(demo, bundle):
    _, df, meta, _ = demo
    base = baseline_row(df, meta)
    levers = adjustable_features(df, meta)
    assert levers
    r = simulate(bundle, meta, base, {levers[0]: -25})
    assert r["scenario"] != r["baseline"]


def test_recommendation_ranking(demo, bundle):
    _, df, meta, _ = demo
    base = baseline_row(df, meta)
    levers = adjustable_features(df, meta)
    table = recommend(bundle, meta, base, levers[:5], 15, {})
    assert list(table.columns).count("Priority score") == 1
    assert table["Priority score"].is_monotonic_decreasing


def test_kpis(demo):
    _, df, meta, _ = demo
    k = kpis(df, meta)
    assert k["total"] > 0


def test_min_rows_enforced():
    tiny = pd.DataFrame({"date": pd.date_range("2025-01-01", periods=10),
                         "x": range(10), "y": range(10)})
    meta = detect_schema(tiny)
    with pytest.raises(Exception):
        clean_data(tiny, meta)


def test_emission_calculator_example():
    from core.emission_calc import calculate
    r = calculate({"electricity": 20, "light": 10, "computer": 15, "generator": 2, "water": 500,
                   "ac": 8, "fan": 5, "bus": 3, "vehicles": 2, "waste": 4, "solar": 5})
    assert abs(r["gross_kg"] - 59.155) < 0.01
    assert abs(r["solar_offset_kg"] - 3.55) < 0.01
    assert abs(r["net_kg"] - 55.605) < 0.01
    assert abs(r["monthly_kg"] - r["net_kg"] * 30) < 0.01
    assert abs(r["yearly_kg"] - r["net_kg"] * 365) < 0.01


def test_emission_calculator_handles_missing_and_negative():
    from core.emission_calc import calculate
    r = calculate({"electricity": -5, "waste": None})
    assert r["gross_kg"] >= 0
    assert r["net_kg"] >= 0


def test_dependency_graph_generic(demo, generic, bundle):
    from core.graph import build_network, explain_node
    _, df, meta, _ = demo
    net = build_network(df, meta, bundle)
    assert net["nodes"][0]["kind"] == "hub"
    assert len(net["nodes"]) == len(meta["features"]) + 1
    assert len(net["edges"]) == len(meta["features"])
    info = explain_node(net, net["nodes"][1]["id"])
    assert info["kind"] == "feature"
    hub_info = explain_node(net, meta["target"])
    assert hub_info["kind"] == "hub" and len(hub_info["top_drivers"]) > 0

    meta2 = detect_schema(generic)
    df2, _ = clean_data(generic, meta2)
    bundle2 = train_models(df2, {**meta2, "epochs": 12})
    net2 = build_network(df2, meta2, bundle2)
    assert len(net2["categories"]) >= 1
