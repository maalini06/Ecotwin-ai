#!/usr/bin/env bash
# Run the test-suite (macOS / Linux).
set -e
cd "$(dirname "$0")"
[ -d ".venv" ] || python3 -m venv .venv
source .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
python -m pytest -q
