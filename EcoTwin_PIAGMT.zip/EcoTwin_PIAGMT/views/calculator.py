"""Daily Emission Calculator: a standalone, formula-based estimator for 11 campus
activities (independent of the trained model). Solar is subtracted as avoided emissions."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from core.emission_calc import ACTIVITIES, SOURCE, calculate
from views.ui import ctx, fmt, page_header, plot

LEFT = [a for a in ACTIVITIES if a["column"] == "left"]
RIGHT = [a for a in ACTIVITIES if a["column"] == "right"]
MID = [a for a in ACTIVITIES if a["column"] == "mid"]


def _field(a: dict):
    live = st.session_state.get(f"calc_{a['key']}", 0.0) or 0.0
    st.markdown(f"**{a['label']}** <span class='muted'>({a['unit']})</span>", unsafe_allow_html=True)
    st.caption(f"Emission factor: {a['factor']:g} kg CO2/{a['unit'].split('/')[0]}"
              + (" avoided" if a.get("offset") else ""))
    qty = st.number_input(a["label"], min_value=0.0, value=0.0, step=1.0, key=f"calc_{a['key']}",
                          label_visibility="collapsed")
    emission = qty * a["factor"]
    sign = "avoided" if a.get("offset") else "emitted"
    st.caption(f"= {emission:,.3f} kg CO2 {sign}/day")
    st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)


def render():
    df, meta, bundle, q = ctx()
    page_header("calculate", "Daily Emission Calculator", "Estimate today's footprint from 11 campus activities")

    st.markdown("#### Enter today's activity")
    left, mid, right = st.columns([5, 4, 5], gap="large")
    with left:
        for a in LEFT:
            _field(a)
    with mid:
        st.markdown("<div style='height:2px'></div>", unsafe_allow_html=True)
        for a in MID:
            _field(a)
    with right:
        for a in RIGHT:
            _field(a)

    st.divider()
    if st.button("Generate Daily Emissions", type="primary", icon=":material/bolt:", width="stretch"):
        quantities = {a["key"]: st.session_state.get(f"calc_{a['key']}", 0.0) for a in ACTIVITIES}
        st.session_state["calc_result"] = calculate(quantities)

    result = st.session_state.get("calc_result")
    if not result:
        st.info("Enter activity amounts above and press **Generate Daily Emissions**.")
        _factor_info()
        return

    st.markdown("#### Results")
    c1, c2, c3 = st.columns(3)
    c1.metric("Gross emissions", fmt(result["gross_kg"], "kg CO2/day"))
    c2.metric("Solar avoided", fmt(result["solar_offset_kg"], "kg CO2/day"))
    c3.metric("Net daily emissions", fmt(result["net_kg"], "kg CO2/day"))
    c4, c5 = st.columns(2)
    c4.metric("Estimated monthly", fmt(result["monthly_kg"], "kg CO2"))
    c5.metric("Estimated yearly", fmt(result["yearly_kg"], "kg CO2"))

    rows = [r for r in result["rows"] if not r.get("offset") and r["quantity"] > 0]
    left_col, right_col = st.columns(2)
    with left_col:
        st.markdown("##### Contribution by activity")
        if rows:
            fig = go.Figure(go.Bar(x=[r["emission_kg"] for r in rows], y=[r["label"] for r in rows],
                                   orientation="h", marker_color="#8B7CF6"))
            fig.update_yaxes(autorange="reversed")
            plot(fig, height=max(280, 34 * len(rows)), legend=False)
        else:
            st.caption("No emitting activity entered yet.")
    with right_col:
        st.markdown("##### Share of gross emissions")
        if rows:
            fig = go.Figure(go.Pie(labels=[r["label"] for r in rows], values=[r["emission_kg"] for r in rows],
                                   hole=0.45))
            plot(fig, height=max(280, 34 * len(rows)))
        else:
            st.caption("No emitting activity entered yet.")

    st.markdown("##### Every activity")
    table = [{"Activity": r["label"], "Quantity": r["quantity"], "Unit": r["unit"],
             "Factor (kg CO2/unit)": r["factor"],
             "Emission (kg CO2/day)": (-r["emission_kg"] if r.get("offset") else r["emission_kg"])}
            for r in result["rows"]]
    st.dataframe(table, width="stretch", height=min(80 + 35 * len(table), 440))

    _factor_info()


def _factor_info():
    with st.expander("Emission Factor Information"):
        st.caption("These factors are configurable assumptions, not fixed constants — adjust them "
                  "in `core/emission_calc.py` if your campus has measured or region-specific values.")
        rows = [{"Activity": a["label"], "Unit": a["unit"],
                "Factor": f"{a['factor']:g} kg CO2/{a['unit'].split('/')[0]}" + (" avoided" if a.get("offset") else ""),
                "Basis": a["note"]} for a in ACTIVITIES]
        st.dataframe(rows, width="stretch", height=min(80 + 35 * len(rows), 420))
        st.caption(f"Source basis: {SOURCE}")
