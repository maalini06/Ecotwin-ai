"""Page 5: risk meter and budget burn-down tracking."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from core.analytics import budget_status, detect_anomalies, risk_level
from views.ui import ctx, fmt, page_header, plot

TONE = {"Low": "good", "Medium": "warn", "High": "bad"}


def render():
    df, meta, bundle, q = ctx()
    page_header("shield", "Risk & Budget", "Composite risk score and monthly budget tracking")

    a = detect_anomalies(df, meta, bundle)
    r = risk_level(df, meta, a)
    tone_color = {"good": "#38BDF8", "warn": "#F5B942", "bad": "#FB7185"}[TONE[r["level"]]]
    st.markdown(
        f'<div class="card"><h4>Overall risk</h4>'
        f'<span class="badge" style="background:{tone_color}22;color:{tone_color};border:1px solid {tone_color}55">'
        f'{r["level"]}</span></div>', unsafe_allow_html=True)
    for line in r["reasons"]:
        st.markdown(f"- {line}")

    st.divider()
    if not meta["date_col"]:
        st.info("Budget tracking needs a date column.")
        return

    st.markdown("#### Monthly budget")
    default_budget = float(df[meta["target"]].tail(30).sum())
    budget = st.number_input(f"Monthly budget ({meta['unit']})", min_value=0.0, value=round(default_budget, 1),
                             step=max(default_budget * 0.05, 1.0))
    if budget <= 0:
        st.warning("Set a budget above zero to see the burn-down.")
        return
    b = budget_status(df, meta, budget)

    c = st.columns(4)
    c[0].metric("Used this month", fmt(b["used"], meta["unit"]))
    c[1].metric("Projected month total", fmt(b["projected"], meta["unit"]))
    c[2].metric("Pace vs. ideal", "Over" if b["over_pace"] else "On/under")
    c[3].metric("Projected to exceed on day", b["exceed_day"] or "Not projected")

    fig = go.Figure()
    fig.add_scatter(x=b["curve"]["Day"], y=b["curve"]["Actual"], name="Actual", line=dict(color="#8B7CF6", width=2))
    fig.add_scatter(x=b["curve"]["Day"], y=b["curve"]["Budget pace"], name="Budget pace",
                    line=dict(color="#F5B942", width=2, dash="dot"))
    fig.add_hline(y=budget, line=dict(color="#FB7185", width=1, dash="dash"), annotation_text="Budget")
    plot(fig, height=380)
    if b["will_exceed"]:
        st.warning(f"At the current pace, {b['month']} is projected to exceed the budget.")
    else:
        st.success(f"At the current pace, {b['month']} is projected to stay within budget.")
