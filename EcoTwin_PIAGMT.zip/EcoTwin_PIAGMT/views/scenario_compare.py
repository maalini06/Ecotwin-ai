"""Scenario Comparison: side-by-side view of scenarios saved from the What-if Simulator."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from views.ui import ctx, fmt, page_header, plot


def render():
    df, meta, bundle, q = ctx()
    page_header("compare_arrows", "Scenario Comparison", "Saved what-if scenarios, side by side")

    saved = st.session_state.get("scenarios", [])
    if not saved:
        st.info("No scenarios saved yet. Go to **What-if Simulator**, generate a scenario, "
                "and press **Save this scenario**.")
        return

    labels = [f"#{i + 1}: " + (", ".join(f"{k} {v:+d}%" for k, v in s["changes"].items()) or "no change")
             for i, s in enumerate(saved)]
    chosen = st.multiselect("Scenarios to compare", labels, default=labels)
    idx = [labels.index(l) for l in chosen]
    if not idx:
        st.warning("Select at least one scenario.")
        return
    picked = [saved[i] for i in idx]

    fig = go.Figure()
    fig.add_bar(name="Baseline", x=[labels[i] for i in idx], y=[picked[i]["baseline"] for i in range(len(picked))],
               marker_color="#465088")
    fig.add_bar(name="Scenario", x=[labels[i] for i in idx], y=[s["scenario"] for s in picked],
               marker_color="#8B7CF6")
    fig.update_layout(barmode="group")
    plot(fig, height=420)

    rows = [{"Scenario": labels[idx[i]], "Baseline": round(s["baseline"], 1),
            "Scenario prediction": round(s["scenario"], 1), "Change": round(s["delta"], 1),
            "Change %": round(s["delta_pct"], 1)} for i, s in enumerate(picked)]
    st.dataframe(rows, width="stretch", height=min(80 + 35 * len(rows), 380))

    best = min(picked, key=lambda s: s["scenario"])
    st.success(f"Lowest predicted {meta['target']}: {fmt(best['scenario'], meta['unit'])} "
              f"({best['delta_pct']:+.1f}% vs. baseline).")
