"""EcoTwin AI — entry point. Dataset upload is always the first stop; every other
module reads the active dataset from session state and works for whatever was uploaded."""
from __future__ import annotations

import streamlit as st

from views import (anomalies, calculator, carbon_graph, command_center, dataset, forecast,
                   overview, recommend, recommend_track, reports, risk, scenario_compare, whatif)
from views.ui import LOGO_MARK, inject_css

st.set_page_config(page_title="EcoTwin AI", page_icon=":material/eco:", layout="wide",
                   initial_sidebar_state="expanded")
inject_css()

PAGES = {
    "Dataset": ("database", dataset),
    "Command Center": ("space_dashboard", command_center),
    "Overview": ("dashboard", overview),
    "Forecast": ("timeline", forecast),
    "Anomalies": ("warning", anomalies),
    "Risk & Budget": ("shield", risk),
    "Carbon Dependency Graph": ("hub", carbon_graph),
    "What-if Simulator": ("tune", whatif),
    "Scenario Comparison": ("compare_arrows", scenario_compare),
    "Roadmap": ("route", recommend),
    "Recommendations & Tracking": ("fact_check", recommend_track),
    "Reports": ("description", reports),
    "Daily Emission Calculator": ("calculate", calculator),
}

st.session_state.setdefault("ready", False)
st.session_state.setdefault("nav", "Dataset")
if st.session_state.pop("goto_landing", False):
    st.session_state["nav"] = "Command Center"

with st.sidebar:
    st.markdown(
        f'<div class="brand"><div class="mark">{LOGO_MARK}</div>'
        '<div><div class="name">EcoTwin AI</div><div class="sub">Data-driven carbon twin</div></div></div>',
        unsafe_allow_html=True)
    locked = not st.session_state["ready"]
    for label, (icon, _mod) in PAGES.items():
        active = st.session_state["nav"] == label
        disabled = locked and label != "Dataset"
        if st.button(label, key=f"nav_{label}", icon=f":material/{icon}:",
                    type="primary" if active else "secondary", disabled=disabled, width="stretch"):
            st.session_state["nav"] = label
            st.rerun()
    if locked:
        st.caption("Upload a dataset to unlock the rest.")
    st.divider()
    if st.session_state["ready"]:
        meta = st.session_state["meta"]
        st.caption(f"Active dataset\n\n**{meta['name']}**\n\nTarget: {meta['target']}")
    else:
        st.caption("No dataset loaded yet.")

nav = st.session_state["nav"]
if nav != "Dataset" and not st.session_state["ready"]:
    st.session_state["nav"] = "Dataset"
    nav = "Dataset"

PAGES[nav][1].render()
