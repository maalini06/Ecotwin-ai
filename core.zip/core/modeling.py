"""PI-AGMT training/scoring (see core/pi_agmt.py) and the univariate time-series forecaster.
Everything is schema-agnostic: it works from the `meta` roles chosen on the dataset page."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

TEST_FRACTION = 0.2


def build_X(df: pd.DataFrame, meta: dict, columns: list[str] | None = None) -> pd.DataFrame:
    feats = [c for c in meta["features"] if c in df.columns]
    X = df[feats].astype(float).copy()
    d = meta.get("date_col")
    if d and d in df.columns:
        dt = pd.to_datetime(df[d])
        X["cal_dayofweek"] = dt.dt.dayofweek
        X["cal_month"] = dt.dt.month
        X["cal_dayofyear"] = dt.dt.dayofyear
    for c in meta.get("categoricals", []):
        if c in df.columns:
            X = pd.concat([X, pd.get_dummies(df[c].astype(str), prefix=f"cat_{c}", dtype=float)], axis=1)
    if columns is not None:
        X = X.reindex(columns=columns, fill_value=0.0)
    return X


def _metrics(y, p) -> dict:
    y, p = np.asarray(y, float), np.asarray(p, float)
    denom = np.where(np.abs(y) < 1e-9, np.nan, np.abs(y))
    return {"MAE": float(mean_absolute_error(y, p)),
            "RMSE": float(np.sqrt(mean_squared_error(y, p))),
            "R2": float(r2_score(y, p)),
            "MAPE": float(np.nanmean(np.abs(y - p) / denom) * 100)}


def train_models(df: pd.DataFrame, meta: dict) -> dict:
    """Train PI-AGMT (Physics-Informed Adaptive Graph-Mamba Transformer) on a chronological split.
    meta may carry: group_col (building/entity column), split_date (validation start), epochs."""
    from core.pi_agmt import train_piagmt
    X = build_X(df, meta)
    if X.shape[1] == 0:
        raise ValueError("No usable feature columns. Select at least one feature or a date column.")
    y = df[meta["target"]].astype(float).values
    return train_piagmt(df, meta, X, y, split_date=meta.get("split_date"))


def predict_rows(bundle: dict, rows: pd.DataFrame, meta: dict) -> np.ndarray:
    """Score feature rows (what-if). A row stands in for one building on the most recent day."""
    X = build_X(rows, meta, columns=bundle["columns"])
    labels = bundle["model"].labels
    g = meta.get("group_col")
    if g and g in rows.columns:
        pos = {l: i for i, l in enumerate(labels)}
        node = np.array([pos.get(str(v), 0) for v in rows[g]])
    else:
        node = np.zeros(len(rows), int)
    return bundle["model"].predict_rows(X.to_numpy(float), node)


# ---------------------------------------------------------------- forecasting
def _series(df: pd.DataFrame, meta: dict) -> pd.Series:
    s = df.groupby(meta["date_col"])[meta["target"]].sum() if df[meta["date_col"]].duplicated().any() \
        else df.set_index(meta["date_col"])[meta["target"]]
    return s.sort_index().astype(float)


def _feat_row(hist: list[float], when: pd.Timestamp, t: int) -> list[float]:
    h = np.asarray(hist)
    lag = lambda k: h[-k] if len(h) >= k else h[0]
    return [lag(1), lag(2), lag(7), h[-7:].mean(), h[-30:].mean(), when.dayofweek, when.month, t]


def forecast_target(df: pd.DataFrame, meta: dict, horizon: int = 30) -> dict:
    if not meta.get("date_col"):
        raise ValueError("Forecasting needs a date column.")
    s = _series(df, meta)
    if len(s) < 40:
        raise ValueError("At least 40 dated records are needed to forecast.")
    step = s.index.to_series().diff().dropna().median()
    step = step if step > pd.Timedelta(0) else pd.Timedelta(days=1)

    rows, ys = [], []
    for i in range(7, len(s)):
        rows.append(_feat_row(list(s.values[:i]), s.index[i], i))
        ys.append(s.values[i])
    X, y = np.array(rows), np.array(ys)
    cut = int(len(X) * (1 - TEST_FRACTION))
    mdl = GradientBoostingRegressor(random_state=42).fit(X[:cut], y[:cut])
    pred = mdl.predict(X[cut:])
    m = _metrics(y[cut:], pred)
    naive = _metrics(y[cut:], X[cut:, 0])
    rmse = m["RMSE"]

    mdl = GradientBoostingRegressor(random_state=42).fit(X, y)
    hist, t0, last = list(s.values), len(s), s.index[-1]
    out = []
    for h in range(1, horizon + 1):
        when = last + step * h
        yhat = float(mdl.predict(np.array([_feat_row(hist, when, t0 + h - 1)]))[0])
        hist.append(yhat)
        band = 1.96 * rmse * (1 + 0.15 * np.sqrt(h))
        out.append({"Date": when, "Forecast": yhat, "Lower": yhat - band, "Upper": yhat + band})
    fc = pd.DataFrame(out)
    recent = s.iloc[-horizon:].mean()
    change = (fc["Forecast"].mean() - recent) / recent * 100 if recent else 0.0
    return {"history": s, "forecast": fc, "metrics": m, "naive": naive, "change_pct": float(change)}
