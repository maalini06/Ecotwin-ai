#!/usr/bin/env bash
# Install dependencies only, without launching the app (macOS / Linux).
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
echo "Setup complete. Run ./run.sh to start the app, or:"
echo "  source .venv/bin/activate && streamlit run app.py"
