"""Dataset ingestion, schema detection, cleaning and quality profiling.
Works for any tabular CSV / Excel file: nothing here assumes column names."""
from __future__ import annotations

import io
import warnings

import numpy as np
import pandas as pd

TARGET_HINTS = ("co2", "emission", "carbon", "total", "consumption", "usage", "energy")
GROUP_HINTS = ("building_id", "building", "site_id", "entity", "zone_id", "block")
MIN_ROWS = 30


class DatasetError(Exception):
    pass


def read_upload(file, name: str | None = None) -> pd.DataFrame:
    name = (name or getattr(file, "name", "data.csv")).lower()
    try:
        if name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(file)
        else:
            raw = file.read() if hasattr(file, "read") else open(file, "rb").read()
            try:
                df = pd.read_csv(io.BytesIO(raw), sep=None, engine="python")
            except Exception:
                df = pd.read_csv(io.BytesIO(raw))
    except Exception as exc:
        raise DatasetError(f"Could not read the file: {exc}") from exc
    df = df.dropna(how="all").dropna(axis=1, how="all")
    df.columns = [str(c).strip() for c in df.columns]
    if df.empty:
        raise DatasetError("The file contains no data.")
    return df


def _to_datetime(s: pd.Series) -> pd.Series:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return pd.to_datetime(s, errors="coerce")


def _numeric_ratio(s: pd.Series) -> float:
    if pd.api.types.is_numeric_dtype(s):
        return 1.0
    return float(pd.to_numeric(s, errors="coerce").notna().mean())


def detect_schema(df: pd.DataFrame) -> dict:
    """Best-guess roles for each column. The user can override every choice."""
    date_col = None
    for c in df.columns:
        s = df[c]
        if pd.api.types.is_numeric_dtype(s) and not any(k in c.lower() for k in ("date", "time")):
            continue
        if pd.api.types.is_datetime64_any_dtype(s) or s.dtype == object or "date" in c.lower():
            parsed = _to_datetime(s)
            if parsed.notna().mean() >= 0.8 and parsed.nunique() > 1:
                date_col = c
                break

    group_col = guess_group(df, date_col)
    numeric = [c for c in df.columns if c not in (date_col, group_col) and _numeric_ratio(df[c]) >= 0.9]
    numeric = [c for c in numeric if df[c].nunique(dropna=True) > 1]

    target = None
    for hint in TARGET_HINTS:
        hits = [c for c in numeric if hint in c.lower()]
        if hits:
            target = hits[-1]
            break
    if target is None and numeric:
        target = numeric[-1]

    features = [c for c in numeric if c != target]
    categoricals = [
        c for c in df.columns
        if c not in numeric and c not in (date_col, group_col) and 1 < df[c].nunique() <= 15
    ]
    return {"date_col": date_col, "target": target, "features": features, "group_col": group_col,
            "categoricals": categoricals, "unit": guess_unit(target)}


def guess_group(df: pd.DataFrame, date_col: str | None) -> str | None:
    """A building/entity column: named like one, 2-200 values, repeating across dates."""
    if not date_col:
        return None
    for hint in GROUP_HINTS:
        for c in df.columns:
            if c != date_col and hint in c.lower() and 2 <= df[c].nunique() <= 200:
                if df.groupby(date_col)[c].nunique().max() == 1 or len(df) > df[c].nunique():
                    return c
    return None


def guess_unit(target: str | None) -> str:
    t = (target or "").lower()
    if "co2" in t:
        return "kg CO2" if t.endswith("kg") or "_kg" in t else "CO2"
    if "kwh" in t:
        return "kWh"
    return "units"


def clean_data(df: pd.DataFrame, meta: dict, clip_negative: bool = False):
    df = df.copy()
    log: list[str] = []
    date_col, target = meta["date_col"], meta["target"]
    if not target or target not in df.columns:
        raise DatasetError("Choose a numeric target column to model.")

    if date_col:
        df[date_col] = _to_datetime(df[date_col])
        bad = int(df[date_col].isna().sum())
        if bad:
            df = df.dropna(subset=[date_col])
            log.append(f"Dropped {bad} rows with unreadable dates.")
        df = df.sort_values(date_col, kind="stable").reset_index(drop=True)
        log.append("Sorted records chronologically.")
    else:
        log.append("No date column selected, row order is treated as time order.")

    num_cols = [target] + [c for c in meta["features"] if c != target]
    for c in num_cols:
        before = df[c].isna().sum()
        df[c] = pd.to_numeric(df[c], errors="coerce")
        coerced = int(df[c].isna().sum() - before)
        if coerced:
            log.append(f"{c}: {coerced} non-numeric values set to missing.")

    n_missing_target = int(df[target].isna().sum())
    if n_missing_target:
        df = df.dropna(subset=[target]).reset_index(drop=True)
        log.append(f"Dropped {n_missing_target} rows with a missing target value.")

    for c in num_cols:
        miss = int(df[c].isna().sum())
        if miss:
            med = df[c].median()
            df[c] = df[c].fillna(med)
            log.append(f"{c}: filled {miss} missing values with the median ({med:.2f}).")

    if clip_negative:
        for c in num_cols:
            neg = int((df[c] < 0).sum())
            if neg:
                df[c] = df[c].clip(lower=0)
                log.append(f"{c}: clipped {neg} negative values to 0.")

    dup = int(df.duplicated().sum())
    if dup:
        df = df.drop_duplicates().reset_index(drop=True)
        log.append(f"Removed {dup} exact duplicate rows.")

    for c in meta.get("categoricals", []):
        if c in df.columns:
            df[c] = df[c].astype(str)

    if len(df) < MIN_ROWS:
        raise DatasetError(f"Only {len(df)} usable rows after cleaning; at least {MIN_ROWS} are needed.")
    log.append(f"Final dataset: {len(df):,} rows.")
    return df, log


def quality_report(raw: pd.DataFrame, clean: pd.DataFrame, meta: dict) -> dict:
    target = meta["target"]
    feats = [c for c in meta["features"] if c in clean.columns]
    rep = {
        "rows": len(clean), "columns": clean.shape[1],
        "missing_cells": int(raw.isna().sum().sum()),
        "duplicates": int(raw.duplicated().sum()),
        "missing_by_col": raw.isna().sum()[lambda s: s > 0].to_dict(),
        "negatives": {c: int((clean[c] < 0).sum()) for c in feats + [target] if (clean[c] < 0).any()},
        "constant_cols": [c for c in raw.columns if raw[c].nunique(dropna=True) <= 1],
    }
    outliers = {}
    for c in feats + [target]:
        q1, q3 = clean[c].quantile([0.25, 0.75])
        iqr = q3 - q1
        if iqr > 0:
            n = int(((clean[c] < q1 - 3 * iqr) | (clean[c] > q3 + 3 * iqr)).sum())
            if n:
                outliers[c] = n
    rep["outliers"] = outliers
    corr = clean[feats + [target]].corr()[target].drop(target) if feats else pd.Series(dtype=float)
    rep["leakage"] = corr[corr.abs() > 0.999].index.tolist()
    rep["corr_with_target"] = corr.sort_values(key=abs, ascending=False)
    rep["date_range"], rep["freq_label"] = None, "n/a"
    if meta["date_col"]:
        d = clean[meta["date_col"]]
        rep["date_range"] = (d.min(), d.max())
        rep["freq_label"] = freq_label(d.drop_duplicates().diff().dropna().median())
    return rep


def freq_label(step) -> str:
    if pd.isna(step):
        return "unknown"
    days = step / pd.Timedelta(days=1)
    if days < 0.9:
        return "sub-daily"
    if days < 1.5:
        return "daily"
    if days < 8:
        return "weekly"
    if days < 40:
        return "monthly"
    return "yearly or coarser"


def adjustable_features(df: pd.DataFrame, meta: dict) -> list[str]:
    """Numeric features that make sense as what-if levers (not calendar fields or flags)."""
    skip = ("month", "weekend", "day", "year", "quarter", "week", "hour", "holiday", "id")
    out = []
    for c in meta["features"]:
        if c not in df.columns or df[c].nunique() <= 2:
            continue
        lc = c.lower()
        if any(lc == k or lc.startswith(k + "_") or lc.endswith("_" + k) for k in skip):
            continue
        out.append(c)
    return out
