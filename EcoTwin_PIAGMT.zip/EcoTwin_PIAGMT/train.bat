@echo off
REM Train PI-AGMT on data\ train+validation files and write results to outputs\ (Windows).
REM Extra options are passed through, e.g.  train.bat --external data\DatasetB.csv --epochs 40
cd /d "%~dp0"
if not exist ".venv" python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
python scripts\train_and_evaluate.py %*
pause
