@echo off
REM External test on Dataset B (uses the Python you already installed the requirements into).
REM Optional: run_external.bat data\MyOtherDataset.csv
cd /d "%~dp0"
set DATA=%1
if "%DATA%"=="" set DATA=data\DatasetB.csv
echo Testing PI-AGMT on %DATA% ...
python scripts\train_and_evaluate.py --no-ablation --external %DATA%
echo.
echo Results: outputs\external_results.csv  and  outputs\external_predictions.csv
pause
