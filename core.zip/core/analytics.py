"""Analytics engines: KPIs, anomalies, risk, budget, what-if simulation, recommendations, insights."""
from __future__ import annotations

import numpy as np
import pandas as pd

from core.modeling import predict_rows

FREQS = {"Daily": "D", "Weekly": "W", "Monthly": "MS"}


def kpis(df: pd.DataFrame, meta: dict, window: int = 30) -> dict:
    t = df[meta["target"]]
    w = max(min(window, len(df) // 2), 1)
    recent, prior = t.iloc[-w:], t.iloc[-2 * w:-w] if len(df) >= 2 * w else t.iloc[-w:]
    change = (recent.mean() - prior.mean()) / prior.mean() * 100 if prior.mean() else 0.0
    return {"total": float(t.sum()), "mean": float(t.mean()), "latest": float(t.iloc[-1]),
            "max": float(t.max()), "min": float(t.min()), "window": w,
            "recent_mean": float(recent.mean()), "change_pct": float(change)}


def aggregate(df: pd.DataFrame, meta: dict, freq_key: str = "Monthly", how: str = "sum") -> pd.DataFrame:
    if not meta["date_col"]:
        return df[[meta["target"]]].reset_index(names="Period")
    g = df.set_index(meta["date_col"])[meta["target"]].resample(FREQS[freq_key])
    out = getattr(g, how)().reset_index()
    out.columns = ["Period", meta["target"]]
    return out


def detect_anomalies(df: pd.DataFrame, meta: dict, bundle: dict, method: str = "Model residual",
                     z: float = 2.5) -> pd.DataFrame:
    t = df[meta["target"]].astype(float)
    if method == "Model residual":
        expected = pd.Series(bundle["fitted_all"], index=df.index)
        resid = t - expected
        score = resid / (resid.std() or 1.0)
    else:
        roll = t.rolling(30, min_periods=10)
        expected = roll.mean().shift(1).bfill()
        sd = roll.std().shift(1).bfill().replace(0, np.nan)
        score = ((t - expected) / sd).fillna(0)
    out = pd.DataFrame({"Date": df[meta["date_col"]] if meta["date_col"] else df.index,
                        "Actual": t, "Expected": expected, "Score": score})
    out["Anomaly"] = out["Score"].abs() >= z
    out["Direction"] = np.where(out["Score"] > 0, "Above expected", "Below expected")
    return out


def risk_level(df: pd.DataFrame, meta: dict, anomalies: pd.DataFrame | None = None) -> dict:
    k = kpis(df, meta)
    pts, reasons = 0, []
    if k["change_pct"] >= 6:
        pts += 2; reasons.append(f"Recent average is up {k['change_pct']:.1f}% versus the prior window.")
    elif k["change_pct"] >= 2:
        pts += 1; reasons.append(f"Recent average is up {k['change_pct']:.1f}% versus the prior window.")
    cv = df[meta["target"]].tail(30).std() / (df[meta["target"]].tail(30).mean() or 1)
    if cv > 0.35:
        pts += 1; reasons.append(f"High short-term volatility (variation {cv * 100:.0f}%).")
    if anomalies is not None and anomalies.tail(30)["Anomaly"].sum() >= 3:
        pts += 1; reasons.append("Several unusual readings in the last 30 records.")
    level = "High" if pts >= 3 else "Medium" if pts >= 1 else "Low"
    if not reasons:
        reasons.append("Emissions are stable with no unusual readings.")
    return {"level": level, "points": pts, "reasons": reasons}


def budget_status(df: pd.DataFrame, meta: dict, budget: float) -> dict:
    d, t = meta["date_col"], meta["target"]
    latest = df[d].max()
    start = latest.replace(day=1)
    m = df[(df[d] >= start)]
    days_in = pd.Period(latest, freq="M").days_in_month
    elapsed = (latest - start).days + 1
    used = float(m[t].sum())
    rate = used / elapsed if elapsed else 0.0
    projected = rate * days_in
    ideal = budget / days_in * elapsed
    curve = pd.DataFrame({"Day": range(1, elapsed + 1)})
    daily = m.groupby(m[d].dt.day)[t].sum().reindex(range(1, elapsed + 1), fill_value=0).cumsum()
    curve["Actual"] = daily.values
    curve["Budget pace"] = [budget / days_in * i for i in curve["Day"]]
    exceed_day = None
    if rate > 0 and used < budget:
        day = elapsed + (budget - used) / rate
        exceed_day = int(round(day)) if day <= days_in else None
    return {"month": start.strftime("%B %Y"), "elapsed": elapsed, "days_in_month": days_in, "used": used,
            "ideal": ideal, "projected": projected, "over_pace": used > ideal,
            "will_exceed": projected > budget, "exceed_day": exceed_day, "curve": curve}


# ---------------------------------------------------------------- what-if
def baseline_row(df: pd.DataFrame, meta: dict, mode: str = "Recent average", n: int = 30) -> pd.DataFrame:
    if mode == "Latest record":
        return df.iloc[[-1]].copy()
    tail = df.tail(n)
    row = df.iloc[[-1]].copy()
    for c in meta["features"]:
        if c in tail.columns:
            row[c] = tail[c].mean()
    return row


def apply_changes(row: pd.DataFrame, changes: dict[str, float]) -> pd.DataFrame:
    out = row.copy()
    for col, pct in changes.items():
        if col in out.columns and pct:
            out[col] = max(float(out[col].iloc[0]) * (1 + pct / 100.0), 0.0)
    return out


def simulate(bundle: dict, meta: dict, base: pd.DataFrame, changes: dict[str, float]) -> dict:
    b = float(predict_rows(bundle, base, meta)[0])
    scen_row = apply_changes(base, changes)
    s = float(predict_rows(bundle, scen_row, meta)[0])
    parts = {}
    for col, pct in changes.items():
        if pct:
            parts[col] = float(predict_rows(bundle, apply_changes(base, {col: pct}), meta)[0]) - b
    return {"baseline": b, "scenario": s, "delta": s - b,
            "delta_pct": (s - b) / b * 100 if b else 0.0, "parts": parts}


def recommend(bundle: dict, meta: dict, base: pd.DataFrame, levers: list[str], step_pct: float,
              effort: dict[str, int]) -> pd.DataFrame:
    b = float(predict_rows(bundle, base, meta)[0])
    rows = []
    for c in levers:
        s = float(predict_rows(bundle, apply_changes(base, {c: -step_pct}), meta)[0])
        saving = b - s
        e = max(int(effort.get(c, 2)), 1)
        rows.append({"Lever": c, "Change": f"-{step_pct:g}%", "Predicted saving": saving,
                     "Saving %": saving / b * 100 if b else 0.0, "Effort (1-3)": e,
                     "Priority score": (saving / b * 100 if b else 0.0) / e})
    out = pd.DataFrame(rows).sort_values("Priority score", ascending=False).reset_index(drop=True)
    out["Phase"] = np.where(out.index < max(len(out) // 3, 1), "Now",
                            np.where(out.index < max(2 * len(out) // 3, 2), "Next", "Later"))
    out.index += 1
    return out


def insights(df: pd.DataFrame, meta: dict, bundle: dict, risk: dict, fc: dict | None) -> list[str]:
    k, unit = kpis(df, meta), meta["unit"]
    out = []
    if abs(k["change_pct"]) < 1:
        out.append(f"{meta['target']} is stable over the last {k['window']} records ({k['change_pct']:+.1f}%).")
    elif k["change_pct"] > 0:
        out.append(f"{meta['target']} rose {k['change_pct']:.1f}% over the last {k['window']} records.")
    else:
        out.append(f"{meta['target']} fell {abs(k['change_pct']):.1f}% over the last {k['window']} records.")
    imp = bundle["importance"]
    if len(imp) and imp.iloc[0] > 0:
        out.append(f"{imp.index[0]} is the strongest driver, explaining about {imp.iloc[0]:.0f}% of model sensitivity.")
    out.append(f"Model is {bundle['best']} (R2 {bundle['results'][bundle['best']]['R2']:.3f} on held-out data).")
    if fc:
        out.append(f"Next-period outlook: average {fc['change_pct']:+.1f}% versus the recent level.")
    out.append(f"Risk level is {risk['level']}. {risk['reasons'][0]}")
    return out
