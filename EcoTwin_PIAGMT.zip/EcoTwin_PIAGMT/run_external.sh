#!/usr/bin/env bash
# External test on Dataset B. Optional: ./run_external.sh data/MyOtherDataset.csv
cd "$(dirname "$0")"
DATA="${1:-data/DatasetB.csv}"
echo "Testing PI-AGMT on $DATA ..."
python3 scripts/train_and_evaluate.py --no-ablation --external "$DATA"
echo
echo "Results: outputs/external_results.csv and outputs/external_predictions.csv"
