"""Build 'Dataset B' (distribution-shift stress test) from Sona_Campus_Combined_Dataset.csv.

Same columns as the Sona data plus 3 extra (EV_Charging_kWh, Campus_Zone, Data_Source), same 14 buildings,
new period 2027-01-01..2027-06-30: hotter weather, hybrid attendance, car-heavy commuting, bigger solar,
a generator-outage wave, per-building shifts. Kept: total kWh = sum of parts, vehicles = cars + two-wheelers,
CO2 = standard factors. Next_Day_CO2_kg = today's CO2 shifted one day per building (last day empty).

    python make_dataset_b.py                                  (looks for the combined file next to the script,
                                                               in ./data, or in the current folder)
    python make_dataset_b.py path/to/Sona_Campus_Combined_Dataset.csv
Output: DatasetB.csv in the same folder as the input file.
"""
import os
import sys

import numpy as np
import pandas as pd

NAME = "Sona_Campus_Combined_Dataset.csv"
HERE = os.path.dirname(os.path.abspath(__file__))
cands = [sys.argv[1]] if len(sys.argv) > 1 else [os.path.join(HERE, NAME), os.path.join(HERE, "data", NAME),
                                                 os.path.join(os.getcwd(), NAME)]
src = next((p for p in cands if os.path.exists(p)), None)
if src is None:
    sys.exit(f"Could not find {NAME}. Put it next to this script or pass its path as an argument.")

rng = np.random.default_rng(2027)
orig = pd.read_csv(src, parse_dates=["Date"])
COLS = list(orig.columns)
need = {"Total_Electricity_kWh", "Generator_Fuel_L", "Bus_Diesel_L", "Water_Consumption_L", "Total_Waste_kg",
        "Number_of_Vehicles", "Next_Day_CO2_kg", "Tomorrow_Holiday", "Tomorrow_Event_Day"}
if need - set(COLS):
    sys.exit(f"{os.path.basename(src)} is missing columns: {sorted(need - set(COLS))}")

new_dates = pd.date_range("2027-01-01", "2027-06-30")
shift = pd.Timedelta(days=343)                       # 49 weeks: same weekday, calendar moved 3 weeks
df = pd.concat([orig[orig.Date == d - shift].assign(Date=d) for d in new_dates], ignore_index=True)
N = len(df)
bld = sorted(df.Building_ID.unique())
fac = df.Building_ID.map(dict(zip(bld, np.exp(rng.normal(0, 0.18, len(bld)))))).to_numpy()
noise = lambda s=0.04: np.exp(rng.normal(0, s, N))   # noqa: E731

df["Avg_Temperature_C"] = (df.Avg_Temperature_C + 2.5 + rng.normal(0, 0.4, N)).round(2)
for c, k in [("Student_Headcount", 0.88), ("Faculty_Headcount", 1.0), ("Staff_Headcount", 1.05)]:
    df[c] = (df[c] * k * noise(0.03)).round().astype(int)
df["Occupancy_Rate"] = ((df.Student_Headcount + df.Faculty_Headcount + df.Staff_Headcount)
                        / df.Estimated_Capacity * 100).clip(upper=100).round(2)

parts = ["AC_Electricity_kWh", "Lighting_kWh", "Fan_kWh", "Computer_Lab_kWh", "Equipment_kWh", "Other_Electricity_kWh"]
df["AC_Electricity_kWh"] *= 1.10 * (1 + 0.04 * (df.Avg_Temperature_C - 30).clip(lower=0) / 2.5)
for c in parts:
    df[c] = (df[c] * fac * noise()).round(2)
df["Total_Electricity_kWh"] = df[parts].sum(axis=1).round(2)
ev_share = rng.uniform(0.02, 0.15, N) * (1 + 0.5 * (df.Date - df.Date.min()).dt.days.to_numpy() / 180)
df["EV_Charging_kWh"] = (df.Other_Electricity_kWh * ev_share).round(2)

# generator outage wave: 8 dates x 5 buildings
fuel_rate = (orig[orig.Power_Outage_Hours > 0].assign(r=lambda x: x.Generator_Fuel_L / x.Power_Outage_Hours)
             .groupby("Building_ID").r.median().reindex(bld).fillna(5.0))
for d in rng.choice(new_dates, 8, replace=False):
    for b in rng.choice(bld, 5, replace=False):
        m = (df.Date == d) & (df.Building_ID == b)
        h = round(float(rng.uniform(3, 8)), 2)
        df.loc[m, "Power_Outage_Hours"] = h
        df.loc[m, "Generator_Fuel_L"] = round(h * float(fuel_rate[b]), 2)

df["Solar_Capacity_kWp"] = (df.Solar_Capacity_kWp * 1.4).round().astype(int)
df["Solar_Utilization_kWh"] = np.minimum(df.Solar_Utilization_kWh * 1.4 * 1.05 * noise(0.05),
                                         df.Total_Electricity_kWh).round(2)
gen_kwh = df.Generator_Fuel_L * 3.328
df["Grid_Electricity_kWh"] = (df.Total_Electricity_kWh - df.Solar_Utilization_kWh - gen_kwh).clip(lower=0).round(2)

for c in ["Drinking_Water_L", "Restroom_Water_L", "Water_Consumption_L"]:
    df[c] = (df[c] * 1.12 * noise()).round(2)
df["Water_Recycling_L"] = (df.Water_Recycling_L * 1.3 * noise()).round(2)
for c in ["Food_Waste_kg", "Paper_Waste_kg", "Plastic_Waste_kg", "Total_Waste_kg", "Recycled_Waste_kg"]:
    df[c] = (df[c] * 0.9 * noise(0.05)).round(2)

df["Two_Wheeler_Count"] = (df.Two_Wheeler_Count * 0.9 * noise(0.05)).round().astype(int)
df["Car_Count"] = (df.Car_Count * 1.25 * noise(0.05)).round().astype(int)
df["Public_Transport_Count"] = (df.Public_Transport_Count * 1.2 * noise(0.05)).round()
df["Number_of_Vehicles"] = df.Two_Wheeler_Count + df.Car_Count
df["Bus_Diesel_L"] = (df.Bus_Diesel_L * 1.15 * noise(0.05)).round(2)

# target: today's CO2 with standard factors, shifted to tomorrow per building
today = (0.71 * df.Total_Electricity_kWh + 2.68 * df.Generator_Fuel_L + 2.68 * df.Bus_Diesel_L
         + 0.00035 * df.Water_Consumption_L + 0.5 * df.Total_Waste_kg + 1.2 * df.Number_of_Vehicles)
df["Next_Day_CO2_kg"] = today.groupby(df.Building_ID).shift(-1).round(2)   # rows are Date-ordered per building

zone = {**dict.fromkeys(["B01", "B02", "B03", "B04"], "North"), **dict.fromkeys(["B05", "B06", "B07", "B08"], "South")}
df["Campus_Zone"] = df.Building_ID.map(zone).fillna("Central")
df["Data_Source"] = np.where(rng.random(N) < 0.92, "Smart Meter", "Manual Log")
df = df.sort_values(["Date", "Building_ID"])[COLS + ["EV_Charging_kWh", "Campus_Zone", "Data_Source"]]
out = os.path.join(os.path.dirname(os.path.abspath(src)), "DatasetB.csv")
df.to_csv(out, index=False)

print(f"Read  {src}\nWrote {out}: {len(df)} rows, {df.Date.nunique()} dates, {df.Building_ID.nunique()} buildings")
print(f"{'column':26s} {'Sona mean':>12s} {'B mean':>12s} {'change':>8s}")
for c in ["Avg_Temperature_C", "Total_Electricity_kWh", "AC_Electricity_kWh", "Generator_Fuel_L",
          "Water_Consumption_L", "Car_Count", "Two_Wheeler_Count", "Next_Day_CO2_kg"]:
    a, b = orig[c].mean(), df[c].mean()
    print(f"{c:26s} {a:12.2f} {b:12.2f} {(b / a - 1) * 100:+7.1f}%")