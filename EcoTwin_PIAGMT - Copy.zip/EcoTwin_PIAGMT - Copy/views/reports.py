"""Page 8: report — consolidated summary suitable for exporting or presenting."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
import streamlit as st

from core.analytics import budget_status, detect_anomalies, insights, kpis, risk_level
from views.ui import ctx, fmt, get_forecast, page_header


def validation_table(bundle: dict) -> pd.DataFrame:
    """Held-out validation scores: the two baselines and PI-AGMT, recomputed for whichever
    validation start date the model was trained with (set on the Dataset page)."""
    rows = [(n, m) for n, m in bundle.get("baselines", {}).items()]
    rows.append(("PI-AGMT (full)", bundle["results"][bundle["best"]]))
    return pd.DataFrame({
        "Model": [n for n, _ in rows],
        "R2": [round(m["R2"], 4) for _, m in rows],
        "MAE": [round(m["MAE"], 3) for _, m in rows],
        "RMSE": [round(m["RMSE"], 3) for _, m in rows],
        "MAPE_%": [round(m["MAPE"], 2) for _, m in rows],
    })


def _md_table(t: pd.DataFrame) -> list[str]:
    out = ["| " + " | ".join(t.columns) + " |", "|" + "|".join("---" for _ in t.columns) + "|"]
    fm = {"R2": "{:.4f}", "MAE": "{:.3f}", "RMSE": "{:.3f}", "MAPE_%": "{:.2f}"}
    for r in t.itertuples(index=False):
        out.append("| " + " | ".join(fm[c].format(v) if c in fm else str(v) for c, v in zip(t.columns, r)) + " |")
    return out


def render():
    df, meta, bundle, q = ctx()
    page_header("description", "Report", "Consolidated summary for export or presentation")

    vt = validation_table(bundle)
    d = bundle.get("dates") or {}
    feats = len([c for c in meta["features"] if c in df.columns])
    st.markdown("#### Validation results")
    cfg = st.columns(5)
    if d.get("train_end") is not None:
        cfg[0].metric("Train end date", f"{d['train_end']:%d-%b-%Y}")
        cfg[1].metric("Validation start", f"{d['test_start']:%d-%b-%Y}")
    cfg[2].metric("Features", feats)
    cfg[3].metric("Target", meta["target"])
    cfg[4].metric("Train / validation rows", f"{bundle['train_size']:,} / {bundle['test_size']:,}")
    st.dataframe(vt, hide_index=True, width="stretch",
                 column_config={"R2": st.column_config.NumberColumn(format="%.4f"),
                                "MAE": st.column_config.NumberColumn(format="%.3f"),
                                "RMSE": st.column_config.NumberColumn(format="%.3f"),
                                "MAPE_%": st.column_config.NumberColumn(format="%.2f")})
    st.caption("Scores update with the validation start date. To change it, set 'Validation starts on' "
               "on the Dataset page and load the dataset again.")
    st.divider()

    k = kpis(df, meta)
    a = detect_anomalies(df, meta, bundle)
    r = risk_level(df, meta, a)
    fc = get_forecast(30)
    fc = None if fc.get("error") else fc

    lines = [f"# EcoTwin AI Report", f"_Generated {datetime.now():%d %b %Y, %H:%M}_", "",
            f"**Dataset:** {meta['name']} ({q['rows']:,} records, target `{meta['target']}` in {meta['unit']})",
            "", "## Key figures",
            f"- Total {meta['target']}: {fmt(k['total'], meta['unit'])}",
            f"- Average per record: {fmt(k['mean'], meta['unit'])}",
            f"- Recent {k['window']}-record trend: {k['change_pct']:+.1f}%",
            f"- Model: {bundle['best']} (R2 {bundle['results'][bundle['best']]['R2']:.3f})",
            f"- Anomalies flagged: {int(a['Anomaly'].sum())} of {len(a)} records",
            f"- Risk level: {r['level']}", ""]
    if fc:
        lines += [f"- 30-period forecast outlook: {fc['change_pct']:+.1f}% vs. recent level", ""]
    vlines = ["## Validation results"]
    if d.get("train_end") is not None:
        vlines += [f"- Train end date: {d['train_end']:%d-%b-%Y}", f"- Validation start: {d['test_start']:%d-%b-%Y}"]
    vlines += [f"- Features: {feats}", f"- Target: {meta['target']}", ""] + _md_table(vt) + [""]
    lines += vlines
    lines += ["## Insights"] + [f"- {x}" for x in insights(df, meta, bundle, r, fc)]
    lines += ["", "## Top drivers"] + [f"- {i}: {v:.1f}%" for i, v in bundle["importance"].head(6).items()]
    if meta["date_col"]:
        try:
            b = budget_status(df, meta, float(df[meta["target"]].tail(30).sum()))
            lines += ["", "## Budget pace", f"- {b['month']}: {fmt(b['used'], meta['unit'])} used, "
                     f"projected {fmt(b['projected'], meta['unit'])}"]
        except Exception:
            pass
    saved = st.session_state.get("scenarios", [])
    if saved:
        lines += ["", "## Saved what-if scenarios"]
        for i, s in enumerate(saved, 1):
            chg = ", ".join(f"{k} {v:+d}%" for k, v in s["changes"].items()) or "no changes"
            lines += [f"- Scenario {i} ({chg}): {s['delta']:+.1f} {meta['unit']} ({s['delta_pct']:+.1f}%)"]
    report_md = "\n".join(lines)

    st.markdown(report_md)
    st.download_button("Download report (Markdown)", report_md.encode(), "ecotwin_report.md", "text/markdown",
                       icon=":material/download:", type="primary")
