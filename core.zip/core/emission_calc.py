"""Daily Carbon Emission Calculator.

Independent of the uploaded dataset's trained model — this is a transparent,
formula-based estimator (activity quantity x emission factor) that lets a
user compute a one-off daily footprint from 11 standard campus activities.
Solar is treated as avoided emissions and is subtracted, never added.
"""
from __future__ import annotations

SOURCE = "CEA India grid average / IPCC 2006 / DEFRA-consistent reference factors (configurable)"

# key, label, unit, emission factor (kg CO2 per unit), column ("left"/"mid"/"right")
ACTIVITIES = [
    {"key": "electricity", "label": "Electricity", "unit": "kWh/day", "factor": 0.71,
     "column": "left", "note": "Grid electricity, CEA India weighted average factor."},
    {"key": "light", "label": "Light", "unit": "kWh/day", "factor": 0.71,
     "column": "left", "note": "Lighting load, billed as grid electricity."},
    {"key": "computer", "label": "Computer Equipment", "unit": "kWh/day", "factor": 0.71,
     "column": "left", "note": "Computers and peripherals, grid electricity."},
    {"key": "generator", "label": "Generator Diesel", "unit": "L/day", "factor": 2.68,
     "column": "left", "note": "Backup generator, IPCC 2006 diesel combustion factor."},
    {"key": "water", "label": "Water", "unit": "L/day", "factor": 0.00035,
     "column": "left", "note": "Supply + treatment, mid-range published LCA studies."},
    {"key": "ac", "label": "AC", "unit": "kWh/day", "factor": 0.71,
     "column": "right", "note": "Air conditioning, grid electricity."},
    {"key": "fan", "label": "Fan", "unit": "kWh/day", "factor": 0.71,
     "column": "right", "note": "Fans, grid electricity."},
    {"key": "bus", "label": "Bus Diesel", "unit": "L/day", "factor": 2.68,
     "column": "right", "note": "Campus bus, IPCC 2006 diesel combustion factor."},
    {"key": "vehicles", "label": "Vehicles", "unit": "trips/day", "factor": 1.2,
     "column": "right", "note": "Private vehicle trips, DEFRA passenger-car factor at ~7 km/trip."},
    {"key": "waste", "label": "Waste", "unit": "kg/day", "factor": 0.5,
     "column": "right", "note": "Mixed waste, DEFRA-consistent landfill factor."},
    {"key": "solar", "label": "Solar", "unit": "kWh/day", "factor": 0.71,
     "column": "mid", "offset": True, "note": "Rooftop solar generation, offsets grid electricity 1:1."},
]

DEFAULTS = {a["key"]: 0.0 for a in ACTIVITIES}


def calculate(quantities: dict) -> dict:
    """quantities: {activity_key: amount}. Missing/invalid entries treated as 0."""
    rows = []
    gross = 0.0
    solar_offset = 0.0
    for a in ACTIVITIES:
        try:
            qty = max(float(quantities.get(a["key"], 0) or 0), 0.0)
        except (TypeError, ValueError):
            qty = 0.0
        emission = round(qty * a["factor"], 3)
        rows.append({**a, "quantity": qty, "emission_kg": emission})
        if a.get("offset"):
            solar_offset += emission
        else:
            gross += emission

    net = gross - solar_offset
    return {
        "rows": rows,
        "gross_kg": round(gross, 3),
        "solar_offset_kg": round(solar_offset, 3),
        "net_kg": round(net, 3),
        "monthly_kg": round(net * 30, 2),
        "yearly_kg": round(net * 365, 2),
    }
