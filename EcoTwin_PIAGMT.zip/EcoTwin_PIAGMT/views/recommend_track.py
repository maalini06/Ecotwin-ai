"""Recommendations & Tracking: generate ranked recommendations on demand, then
track which ones have been applied."""
from __future__ import annotations

import streamlit as st

from core.analytics import baseline_row, recommend
from core.data import adjustable_features
from views.ui import ctx, fmt, page_header


def render():
    df, meta, bundle, q = ctx()
    page_header("fact_check", "Recommendations & Tracking", "Generate ranked actions and track progress")

    levers = adjustable_features(df, meta)
    if not levers:
        st.info("No adjustable numeric features were found for this dataset.")
        return

    step = st.slider("Reduction to evaluate per lever", 5, 50, 15, 5, format="%d%%")
    if st.button("Generate Recommendations", type="primary", icon=":material/auto_awesome:"):
        base = baseline_row(df, meta, "Recent average")
        table = recommend(bundle, meta, base, levers, step, {})
        st.session_state["rec_table"] = table
        tracked = st.session_state.setdefault("rec_tracked", {})
        for lever in table["Lever"]:
            tracked.setdefault(lever, False)

    table = st.session_state.get("rec_table")
    if table is None:
        st.info("Press **Generate Recommendations** to rank reduction actions for this dataset.")
        return

    tracked = st.session_state.setdefault("rec_tracked", {})
    done = sum(1 for v in tracked.values() if v)
    st.progress(done / len(tracked) if tracked else 0, text=f"{done} of {len(tracked)} actions applied")

    for rank, row in table.iterrows():
        lever = row["Lever"]
        c1, c2 = st.columns([1, 5])
        with c1:
            tracked[lever] = st.checkbox("Applied", value=tracked.get(lever, False),
                                         key=f"track_{lever}", label_visibility="collapsed")
        with c2:
            state_tag = "Applied" if tracked[lever] else row["Phase"]
            tone = "good" if tracked[lever] else ("info" if row["Phase"] == "Now" else "warn")
            color = {"good": "#38BDF8", "info": "#8B7CF6", "warn": "#F5B942"}[tone]
            st.markdown(
                f"<div class='card' style='margin-bottom:8px'>"
                f"<b>{rank}. {lever}</b> &nbsp; "
                f"<span class='badge' style='background:{color}22;color:{color};border:1px solid {color}55'>"
                f"{state_tag}</span><br>"
                f"<span class='muted'>Predicted saving {fmt(row['Predicted saving'], meta['unit'])} "
                f"({row['Saving %']:.1f}%) at {row['Change']} · effort {row['Effort (1-3)']}/3</span>"
                f"</div>", unsafe_allow_html=True)

    st.download_button("Download recommendations", table.to_csv().encode(), "recommendations.csv",
                       "text/csv", icon=":material/download:")
