"""Page: what-if simulator — adjust levers, press Generate Scenario to see the predicted
impact, and keep a saved scenario board."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from core.analytics import baseline_row, simulate
from core.data import adjustable_features
from views.ui import ctx, fmt, page_header, plot


def render():
    df, meta, bundle, q = ctx()
    page_header("tune", "What-if Simulator", "Adjust activity levers, then generate the scenario")

    levers = adjustable_features(df, meta)
    if not levers:
        st.info("No adjustable numeric features were found for this dataset.")
        return

    mode = st.radio("Baseline", ["Recent average", "Latest record"], horizontal=True)
    base = baseline_row(df, meta, mode)

    st.markdown("#### Levers")
    changes, cols = {}, st.columns(2)
    for i, c in enumerate(levers):
        with cols[i % 2]:
            pct = st.slider(c, -80, 80, 0, 5, key=f"sim_{c}")
            if pct:
                changes[c] = pct

    generate = st.button("Generate Scenario", type="primary", icon=":material/play_arrow:")
    if generate:
        st.session_state["whatif_result"] = {"changes": dict(changes),
                                             **simulate(bundle, meta, base, changes)}

    r = st.session_state.get("whatif_result")
    if not r:
        st.info("Set the levers above and press **Generate Scenario** to see the predicted impact.")
        return

    c1, c2, c3 = st.columns(3)
    c1.metric("Baseline prediction", fmt(r["baseline"], meta["unit"]))
    c2.metric("Scenario prediction", fmt(r["scenario"], meta["unit"]))
    c3.metric("Change", f"{r['delta']:+.1f} ({r['delta_pct']:+.1f}%)", delta_color="inverse")

    if r["parts"]:
        fig = go.Figure(go.Waterfall(
            orientation="v", measure=["relative"] * len(r["parts"]) + ["total"],
            x=list(r["parts"].keys()) + ["Scenario"],
            y=list(r["parts"].values()) + [r["baseline"] + sum(r["parts"].values())],
            base=r["baseline"],
            increasing=dict(marker_color="#FB7185"), decreasing=dict(marker_color="#38BDF8"),
            totals=dict(marker_color="#8B7CF6")))
        plot(fig, height=400, legend=False)

    if st.button("Save this scenario", icon=":material/bookmark_add:"):
        st.session_state.setdefault("scenarios", []).append(dict(r))
        st.toast("Scenario saved. See it on the Scenario Comparison page.")

    saved = st.session_state.get("scenarios", [])
    if saved:
        st.markdown("#### Saved scenarios")
        rows = [{"#": i + 1, "Levers": ", ".join(f"{k} {v:+d}%" for k, v in s["changes"].items()) or "-",
                "Predicted": round(s["scenario"], 1), "Change %": round(s["delta_pct"], 1)}
               for i, s in enumerate(saved)]
        st.dataframe(rows, width="stretch", height=min(60 + 35 * len(rows), 300))
        if st.button("Clear saved scenarios"):
            st.session_state["scenarios"] = []
            st.rerun()
