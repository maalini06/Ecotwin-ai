@echo off
REM Scores 18 deliberately damaged copies of Dataset B and proves nothing crashes.
cd /d "%~dp0"
python scripts\robustness_test.py
echo.
echo Results: outputs\external_robustness.csv
pause
