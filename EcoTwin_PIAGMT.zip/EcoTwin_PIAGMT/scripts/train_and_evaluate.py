"""
Train PI-AGMT on Sona Campus training data,
validate on Sona Campus validation data,
and optionally evaluate Dataset B as an
untouched external distribution-shift test.

Files:
    data/Sona_Campus_train.csv
    data/Sona_Campus_validation.csv
    data/DatasetB.csv

Target:
    Next_Day_CO2_kg

Usage:
    python scripts/train_and_evaluate.py

    python scripts/train_and_evaluate.py --external data/DatasetB.csv

    python scripts/train_and_evaluate.py --no-ablation --epochs 30
"""

import argparse
import os
import sys
import time

import pandas as pd


# ============================================================
# PROJECT ROOT
# ============================================================

ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

sys.path.insert(0, ROOT)


# ============================================================
# PROJECT IMPORTS
# ============================================================

from core.data import clean_data
from core.modeling import build_X
from core.pi_agmt import (
    evaluate_frame,
    train_piagmt,
)


# ============================================================
# DATASET CONFIGURATION
# ============================================================

TARGET = "Next_Day_CO2_kg"

GROUP = "Building_ID"

DATE = "Date"

CATEGORICAL = [
    "Academic_Term"
]


# Columns that must NOT be used as model features
NOT_FEATURES = [
    "Building_Name",
    "Department",
    TARGET,
    DATE,
    GROUP,
]


# ============================================================
# TOMORROW FEATURES
# ============================================================

# Your actual dataset already contains:
#
#     Tomorrow_Holiday
#     Tomorrow_Event_Day
#
# Therefore these are treated as legitimate
# next-day forecasting inputs.
#
# The remaining flags are only created if they
# exist in the dataset.

CALENDAR_FLAGS = [
    "Weekend",
    "Holiday",
    "Exam_Day",
    "Event_Day",
    "Placement_Period",
    "Project_Period",
]


# ============================================================
# ADD TOMORROW INFORMATION
# ============================================================

def add_tomorrow(df):
    """
    Add tomorrow's calendar information per building.

    The uploaded Sona datasets already contain:
        Tomorrow_Holiday
        Tomorrow_Event_Day

    Therefore those columns are kept as-is.

    Other Tomorrow_* columns are created only when
    their corresponding current-day column exists.
    """

    df = df.sort_values(
        [GROUP, DATE]
    ).copy()

    for c in CALENDAR_FLAGS:

        tomorrow_col = f"Tomorrow_{c}"

        if (
            c in df.columns
            and tomorrow_col not in df.columns
        ):

            df[tomorrow_col] = (
                df.groupby(GROUP)[c]
                .shift(-1)
            )

    return (
        df.sort_values(
            [DATE, GROUP]
        )
        .reset_index(drop=True)
    )


# ============================================================
# LOAD DATA
# ============================================================

def load(path):

    df = pd.read_csv(
        path,
        parse_dates=[DATE]
    )

    # Remove accidental spaces from column names
    df.columns = [
        str(c).strip()
        for c in df.columns
    ]

    # Make sure Building_ID is consistent
    df[GROUP] = (
        df[GROUP]
        .astype(str)
        .str.strip()
    )

    df = (
        df.sort_values(
            [DATE, GROUP]
        )
        .reset_index(drop=True)
    )

    return df


# ============================================================
# CREATE MODEL METADATA
# ============================================================

def make_meta(df, name):

    features = []

    for c in df.columns:

        if c in NOT_FEATURES:
            continue

        if c in CATEGORICAL:
            continue

        if pd.api.types.is_numeric_dtype(
            df[c]
        ):
            features.append(c)

    return {
        "date_col": DATE,
        "group_col": GROUP,
        "target": TARGET,
        "features": features,
        "categoricals": [
            c
            for c in CATEGORICAL
            if c in df.columns
        ],
        "unit": "kg CO2",
        "name": name,
    }


# ============================================================
# PREPARE DATA
# ============================================================

def prepare(
    df,
    meta,
    medians
):

    df = df.copy()

    # Convert training feature columns to numeric
    for c in meta["features"]:

        if c in df.columns:

            df[c] = pd.to_numeric(
                df[c],
                errors="coerce"
            )

    # Fill missing feature values
    # using TRAINING medians
    df[meta["features"]] = (
        df[meta["features"]]
        .fillna(medians)
    )

    # Use project's standard cleaning
    df, _ = clean_data(
        df,
        meta
    )

    return df


# ============================================================
# FORMAT METRICS
# ============================================================

def row(name, metrics):

    return {
        "Model": name,
        "R2": round(
            metrics["R2"],
            4
        ),
        "MAE": round(
            metrics["MAE"],
            3
        ),
        "RMSE": round(
            metrics["RMSE"],
            3
        ),
        "MAPE_%": round(
            metrics["MAPE"],
            2
        ),
    }


# ============================================================
# EXTERNAL DATASET B
# ============================================================

def run_external(
    args,
    bundle,
    meta,
    medians,
    train_df
):

    """
    Evaluate Dataset B WITHOUT retraining.

    Dataset B is an external distribution-shift
    stress-test dataset.

    Training:
        Sona_Campus_train.csv

    Validation:
        Sona_Campus_validation.csv

    External test:
        DatasetB.csv
    """

    # --------------------------------------------------------
    # LOAD DATASET B
    # --------------------------------------------------------

    try:

        ext = pd.read_csv(
            args.external
        )

    except Exception as exc:

        print(
            f"\nCould not read "
            f"{args.external}: {exc}"
        )

        return

    ext.columns = [
        str(c).strip()
        for c in ext.columns
    ]

    # --------------------------------------------------------
    # REQUIRED COLUMNS
    # --------------------------------------------------------

    required = [
        DATE,
        GROUP
    ]

    missing_required = [
        c
        for c in required
        if c not in ext.columns
    ]

    if missing_required:

        print(
            "\nDataset B is missing "
            f"required columns: "
            f"{missing_required}"
        )

        return

    # --------------------------------------------------------
    # DATE
    # --------------------------------------------------------

    notes = []

    ext[DATE] = pd.to_datetime(
        ext[DATE],
        errors="coerce"
    )

    bad_dates = int(
        ext[DATE].isna().sum()
    )

    if bad_dates:

        ext = ext.dropna(
            subset=[DATE]
        )

        notes.append(
            f"{bad_dates} row(s) with "
            "unreadable dates dropped."
        )

    # --------------------------------------------------------
    # BUILDING ID
    # --------------------------------------------------------

    ext[GROUP] = (
        ext[GROUP]
        .astype(str)
        .str.strip()
    )

    # Keep only buildings known during training
    known_buildings = set(
        bundle["nodes"]
    )

    unknown = ext[
        ~ext[GROUP].isin(
            known_buildings
        )
    ]

    if len(unknown):

        notes.append(
            f"{len(unknown)} row(s) from "
            f"unknown buildings "
            f"{sorted(unknown[GROUP].unique())[:5]} "
            "ignored."
        )

        ext = ext[
            ext[GROUP].isin(
                known_buildings
            )
        ]

    # --------------------------------------------------------
    # SORT
    # --------------------------------------------------------

    ext = (
        ext.sort_values(
            [DATE, GROUP]
        )
        .reset_index(drop=True)
    )

    if ext.empty:

        print(
            "\nNo usable rows left "
            "in Dataset B."
        )

        return

    # --------------------------------------------------------
    # NUMERIC FEATURES
    # --------------------------------------------------------

    for c in meta["features"]:

        if c in ext.columns:

            ext[c] = pd.to_numeric(
                ext[c],
                errors="coerce"
            )

    # --------------------------------------------------------
    # CATEGORICAL FEATURES
    # --------------------------------------------------------

    for c in meta["categoricals"]:

        train_mode = (
            train_df[c]
            .mode()
            .iloc[0]
        )

        if c not in ext.columns:

            ext[c] = train_mode

            notes.append(
                f"Category column "
                f"{c} missing; "
                f"filled with training "
                f"value '{train_mode}'."
            )

        else:

            ext[c] = (
                ext[c]
                .fillna(train_mode)
                .astype(str)
            )

    # --------------------------------------------------------
    # TARGET
    # --------------------------------------------------------

    # Dataset B created by make_dataset_b.py
    # already contains:
    #
    #     Next_Day_CO2_kg
    #
    # Therefore use it directly.

    if TARGET not in ext.columns:

        print(
            f"\nDataset B does not contain "
            f"the required target "
            f"'{TARGET}'."
        )

        notes.append(
            f"Missing target: {TARGET}"
        )

        y = None

    else:

        y = pd.to_numeric(
            ext[TARGET],
            errors="coerce"
        ).to_numpy(
            dtype=float
        )

    # --------------------------------------------------------
    # TOMORROW FEATURES
    # --------------------------------------------------------

    if not args.no_tomorrow:

        ext = add_tomorrow(
            ext
        )

    # --------------------------------------------------------
    # EVALUATE WITHOUT RETRAINING
    # --------------------------------------------------------

    result = evaluate_frame(
        bundle,
        ext,
        meta,
        y
    )

    notes += result["notes"]

    print(
        "\n================================================"
    )

    print(
        "EXTERNAL TEST - DATASET B"
    )

    print(
        "================================================"
    )

    print(
        f"File: {args.external}"
    )

    print(
        f"Dates: {result['dates']}"
    )

    print(
        f"Building-days scored: "
        f"{result['scored_cells']}"
    )

    print(
        "Model retrained on Dataset B: NO"
    )

    for note in notes:

        print(
            "  note:",
            note
        )

    # --------------------------------------------------------
    # SAVE PREDICTIONS
    # --------------------------------------------------------

    pred = ext[
        [DATE, GROUP]
    ].copy()

    pred[
        "Predicted_Next_Day_CO2_kg"
    ] = (
        result["predictions"]
        .round(2)
    )

    if y is not None:

        pred[
            "Actual_Next_Day_CO2_kg"
        ] = y

    pred.to_csv(
        os.path.join(
            args.out,
            "external_predictions.csv"
        ),
        index=False
    )

    # --------------------------------------------------------
    # SAVE EXTERNAL RESULTS
    # --------------------------------------------------------

    if result["model"]:

        external_table = pd.DataFrame(
            [
                row(
                    "PI-AGMT (Dataset B)",
                    result["model"]
                )
            ]
            +
            [
                row(
                    name,
                    metrics
                )
                for name, metrics
                in result[
                    "baselines"
                ].items()
            ]
        )

        external_table.to_csv(
            os.path.join(
                args.out,
                "external_results.csv"
            ),
            index=False
        )

        print(
            "\nDATASET B RESULTS"
        )

        print(
            external_table.to_string(
                index=False
            )
        )

    else:

        print(
            "\nDataset B predictions "
            "saved, but no accuracy "
            "score was available."
        )


# ============================================================
# MAIN
# ============================================================

def main():

    parser = argparse.ArgumentParser()

    # ========================================================
    # CORRECT CURRENT FILE NAMES
    # ========================================================

    parser.add_argument(
        "--train",
        default=os.path.join(
            ROOT,
            "data",
            "Sona_Campus_train.csv"
        )
    )

    parser.add_argument(
        "--val",
        default=os.path.join(
            ROOT,
            "data",
            "Sona_Campus_validation.csv"
        )
    )

    parser.add_argument(
        "--external",
        help=(
            "External Dataset B CSV. "
            "Example: data/DatasetB.csv"
        )
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=60
    )

    parser.add_argument(
        "--no-ablation",
        action="store_true"
    )

    parser.add_argument(
        "--no-tomorrow",
        action="store_true",
        help=(
            "Do not use tomorrow calendar "
            "features."
        )
    )

    parser.add_argument(
        "--out",
        default=os.path.join(
            ROOT,
            "outputs"
        )
    )

    args = parser.parse_args()

    os.makedirs(
        args.out,
        exist_ok=True
    )

    # ========================================================
    # LOAD TRAINING + VALIDATION
    # ========================================================

    print(
        "\nLoading datasets..."
    )

    train_df = load(
        args.train
    )

    validation_df = load(
        args.val
    )

    print(
        f"Training dataset: "
        f"{len(train_df):,} rows"
    )

    print(
        f"Validation dataset: "
        f"{len(validation_df):,} rows"
    )

    # ========================================================
    # TOMORROW FEATURES
    # ========================================================

    if not args.no_tomorrow:

        train_max_date = (
            train_df[DATE].max()
        )

        both = add_tomorrow(
            pd.concat(
                [
                    train_df,
                    validation_df
                ],
                ignore_index=True
            )
        )

        train_df = both[
            both[DATE]
            <= train_max_date
        ].copy()

        validation_df = both[
            both[DATE]
            > train_max_date
        ].copy()

    # ========================================================
    # METADATA
    # ========================================================

    meta = make_meta(
        train_df,
        "Sona Campus"
    )

    # ========================================================
    # TRAINING MEDIANS
    # ========================================================

    medians = (
        train_df[
            meta["features"]
        ]
        .apply(
            pd.to_numeric,
            errors="coerce"
        )
        .median()
    )

    # ========================================================
    # COMBINE FOR MODEL PIPELINE
    # ========================================================

    full = prepare(
        pd.concat(
            [
                train_df,
                validation_df
            ],
            ignore_index=True
        ),
        meta,
        medians
    )

    # ========================================================
    # VALIDATION SPLIT
    # ========================================================

    split_date = (
        validation_df[DATE]
        .min()
    )

    meta["split_date"] = split_date

    print(
        "\n================================================"
    )

    print(
        "PI-AGMT DATA CONFIGURATION"
    )

    print(
        "================================================"
    )

    print(
        f"Train file      : "
        f"{os.path.basename(args.train)}"
    )

    print(
        f"Validation file : "
        f"{os.path.basename(args.val)}"
    )

    print(
        f"Train end date  : "
        f"{train_df[DATE].max():%d-%b-%Y}"
    )

    print(
        f"Validation start: "
        f"{split_date:%d-%b-%Y}"
    )

    print(
        f"Features        : "
        f"{len(meta['features'])}"
    )

    print(
        f"Target          : "
        f"{TARGET}"
    )

    # ========================================================
    # BUILD MODEL INPUT
    # ========================================================

    X = build_X(
        full,
        meta
    )

    y = (
        full[TARGET]
        .astype(float)
        .values
    )

    # ========================================================
    # MODEL RUNS
    # ========================================================

    runs = [
        (
            "PI-AGMT (full)",
            {}
        )
    ]

    if not args.no_ablation:

        runs += [
            (
                "PI-AGMT without physics baseline",
                {
                    "use_physics": False
                }
            ),
            (
                "PI-AGMT without graph attention",
                {
                    "use_graph": False
                }
            ),
            (
                "PI-AGMT without Mamba (no history)",
                {
                    "use_temporal": False
                }
            )
        ]

    # ========================================================
    # TRAIN
    # ========================================================

    table = []

    main_bundle = None

    for name, flags in runs:

        start = time.time()

        bundle = train_piagmt(
            full,
            meta,
            X,
            y,
            split_date=split_date,
            epochs=args.epochs,
            importance=(
                main_bundle is None
            ),
            **flags
        )

        elapsed = (
            time.time()
            - start
        )

        print(
            f"{name:45s} "
            f"R2 "
            f"{bundle['results']['PI-AGMT']['R2']:.4f} "
            f"({elapsed:.0f}s)"
        )

        if main_bundle is None:

            main_bundle = bundle

            table += [
                row(
                    model_name,
                    metrics
                )
                for model_name, metrics
                in bundle[
                    "baselines"
                ].items()
            ]

        table.append(
            row(
                name,
                bundle[
                    "results"
                ][
                    "PI-AGMT"
                ]
            )
        )

    # ========================================================
    # VALIDATION RESULTS
    # ========================================================

    results = pd.DataFrame(
        table
    )

    results.to_csv(
        os.path.join(
            args.out,
            "validation_results.csv"
        ),
        index=False
    )

    print(
        "\n================================================"
    )

    print(
        "VALIDATION RESULTS"
    )

    print(
        "================================================"
    )

    print(
        results.to_string(
            index=False
        )
    )

    # ========================================================
    # VALIDATION PREDICTIONS
    # ========================================================

    main_bundle[
        "test_frame"
    ].to_csv(
        os.path.join(
            args.out,
            "validation_predictions.csv"
        ),
        index=False
    )

    # ========================================================
    # FEATURE IMPORTANCE
    # ========================================================

    main_bundle[
        "importance"
    ].head(20).round(3).to_csv(
        os.path.join(
            args.out,
            "feature_importance.csv"
        ),
        header=[
            "importance_%"
        ]
    )

    # ========================================================
    # BUILDING ATTENTION
    # ========================================================

    if main_bundle[
        "attention"
    ]:

        attention = (
            main_bundle[
                "attention"
            ]
        )

        pd.DataFrame(
            attention["matrix"],
            index=attention["labels"],
            columns=attention["labels"]
        ).round(4).to_csv(
            os.path.join(
                args.out,
                "building_attention.csv"
            )
        )

    # ========================================================
    # ERROR BY BUILDING
    # ========================================================

    test_frame = (
        main_bundle[
            "test_frame"
        ]
    )

    if "Building" in test_frame:

        error = (
            test_frame.assign(
                AbsErr=(
                    test_frame["Actual"]
                    -
                    test_frame["Predicted"]
                ).abs()
            )
            .groupby(
                "Building"
            )
            .AbsErr
            .mean()
            .round(2)
        )

        error.to_csv(
            os.path.join(
                args.out,
                "error_by_building.csv"
            ),
            header=[
                "MAE"
            ]
        )

    # ========================================================
    # DATASET B EXTERNAL TEST
    # ========================================================

    if args.external:

        run_external(
            args,
            main_bundle,
            meta,
            medians,
            train_df
        )

    # ========================================================
    # FINISHED
    # ========================================================

    print(
        f"\nAll files written to:"
        f"\n{args.out}"
    )


if __name__ == "__main__":
    main()