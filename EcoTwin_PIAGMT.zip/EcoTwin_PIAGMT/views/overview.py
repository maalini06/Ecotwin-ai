"""Page 2: overview — KPIs, trend, composition, model performance, auto insights."""
from __future__ import annotations

import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from core.analytics import insights, kpis, risk_level
from views.ui import ctx, fmt, get_forecast, page_header, plot


def render():
    df, meta, bundle, q = ctx()
    page_header("dashboard", "Overview", f"{meta['name']} · {len(df):,} records")

    k = kpis(df, meta)
    c = st.columns(4)
    c[0].metric(f"Total {meta['target']}", fmt(k["total"], meta["unit"]))
    c[1].metric("Average per record", fmt(k["mean"], meta["unit"]))
    c[2].metric("Latest record", fmt(k["latest"], meta["unit"]))
    c[3].metric(f"Recent {k['window']}-record trend", f"{k['change_pct']:+.1f}%",
               delta=f"{k['change_pct']:+.1f}%", delta_color="inverse")

    left, right = st.columns([3, 2], gap="large")
    with left:
        st.markdown("#### Trend over time")
        if meta["date_col"]:
            fig = px.line(df, x=meta["date_col"], y=meta["target"])
            fig.update_traces(line=dict(width=2, color="#8B7CF6"))
            roll = df[meta["target"]].rolling(max(len(df) // 20, 3), min_periods=1).mean()
            fig.add_scatter(x=df[meta["date_col"]], y=roll, mode="lines",
                            line=dict(width=2, color="#38BDF8", dash="dot"), name="Trend")
        else:
            fig = px.line(df, y=meta["target"])
        plot(fig)
    with right:
        st.markdown("#### Top drivers")
        imp = bundle["importance"].head(8)
        fig = go.Figure(go.Bar(x=imp.values, y=imp.index, orientation="h",
                               marker_color="#38BDF8"))
        fig.update_yaxes(autorange="reversed")
        plot(fig, height=380, legend=False)

    st.markdown("#### Model performance")
    cols = st.columns(len(bundle["results"]))
    for col, (name, r) in zip(cols, bundle["results"].items()):
        tag = ""
        with col:
            st.markdown(f"**{name}{tag}**")
            st.caption(f"R2 {r['R2']:.3f} · RMSE {r['RMSE']:.2f} · MAE {r['MAE']:.2f}")

    base = bundle.get("baselines")
    if base:
        st.caption("Reference baselines on the same held-out data (no learning): " + " · ".join(
            f"{n}: R2 {r['R2']:.3f}, MAE {r['MAE']:.2f}" for n, r in base.items()))

    st.markdown("#### Automatic insights")
    r = risk_level(df, meta)
    fc = get_forecast(14)
    fc = None if fc.get("error") else fc
    for line in insights(df, meta, bundle, r, fc):
        st.markdown(f"- {line}")
