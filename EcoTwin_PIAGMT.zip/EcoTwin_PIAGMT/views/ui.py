"""Shared look and feel: theme CSS, chart styling, page header, context guard."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

PALETTE = ["#8B7CF6", "#38BDF8", "#F5B942", "#F472B6", "#A78BFA", "#22D3EE", "#FB7185", "#818CF8"]
TONES = {"good": "#38BDF8", "warn": "#F5B942", "bad": "#FB7185", "info": "#8B7CF6"}

CSS = """
<style>
.block-container {padding-top: 2.2rem; max-width: 1280px;}
h1, h2, h3 {letter-spacing: -0.01em;}
[data-testid="stMetric"] {
  background: linear-gradient(160deg, #191E36 0%, #141830 100%);
  border: 1px solid #2A3052; border-radius: 14px; padding: 16px 18px;
}
[data-testid="stMetricLabel"] p {color: #9AA1C7; font-size: 0.82rem; text-transform: uppercase; letter-spacing: .05em;}
[data-testid="stMetricValue"] {
  white-space: normal; overflow: visible; text-overflow: unset;
  word-break: break-word; line-height: 1.2; font-size: clamp(1rem, 2.1vw, 1.7rem);
}
[data-testid="stSidebar"] {border-right: 1px solid #23284A;}
[data-testid="stSidebarContent"] {padding-left: 14px; padding-right: 14px;}
.brand {display:flex; align-items:center; gap:10px; margin: 4px 0 16px 0; padding-left: 2px;}
.brand .mark {width:26px; height:26px; border-radius:8px; display:flex; align-items:center; justify-content:center;
  background: #141830; border:1px solid #23284A; flex-shrink:0;}
.brand .mark svg {width:20px; height:20px;}
.brand .name {font-weight:700; font-size:1.05rem; line-height:1.1;}
.brand .sub {font-size:.72rem; color:#9AA1C7;}

/* Sidebar navigation: one straight column, icon column fixed-width so every
   label starts at the same x, and every icon's left edge lines up with the
   EcoTwin AI mark above it. */
[data-testid="stSidebar"] div[data-testid="stVerticalBlock"] > div:has(> div > .stButton) {gap: 0.2rem;}
[data-testid="stSidebar"] .stButton {margin: 0; padding: 0;}
[data-testid="stSidebar"] .stButton > button {
  display: flex; align-items: center; justify-content: flex-start;
  width: 100%; text-align: left; gap: 12px;
  background: transparent; border: 1px solid transparent; border-radius: 10px;
  color: #C9CEEA; font-weight: 600; padding: 9px 10px 9px 2px;
}
[data-testid="stSidebar"] .stButton > button [data-testid="stIconMaterial"] {
  width: 26px; min-width: 26px; flex: 0 0 26px;
  display: flex; justify-content: center; font-size: 1.15rem;
}
[data-testid="stSidebar"] .stButton > button p {
  margin: 0; text-align: left; font-weight: 600; font-size: .92rem;
}
[data-testid="stSidebar"] .stButton > button:hover:not(:disabled) {
  background: #1B2040; border-color: #2A3052; color: #fff;
}
[data-testid="stSidebar"] .stButton > button[kind="primary"] {
  background: linear-gradient(135deg, rgba(139,124,246,.30), rgba(56,189,248,.16));
  border-color: #8B7CF6; color: #fff;
}
[data-testid="stSidebar"] .stButton > button:disabled {opacity: .38;}
.hero {
  border: 1px solid #2A3052; border-radius: 20px; padding: 34px 38px; margin-bottom: 22px;
  background: radial-gradient(900px 300px at 0% 0%, rgba(139,124,246,.28), transparent 60%),
              radial-gradient(700px 300px at 100% 100%, rgba(56,189,248,.20), transparent 60%), #141830;
}
.hero h1 {margin: 0 0 6px 0; font-size: 2rem;}
.hero p {color: #B4BADB; margin: 0; max-width: 720px; font-size: 1.02rem;}
.chip {display:inline-block; padding:3px 11px; border-radius:999px; font-size:.76rem; font-weight:600;
  border:1px solid #2A3052; background:#1B2040; color:#C9CEEA; margin-right:6px;}
.badge {display:inline-block; padding:4px 14px; border-radius:999px; font-weight:700; font-size:.9rem;}
.card {border:1px solid #2A3052; background:#161A2E; border-radius:14px; padding:16px 18px; height:100%;}
.card h4 {margin:0 0 8px 0; font-size:.95rem; color:#C9CEEA;}
.muted {color:#9AA1C7; font-size:.88rem;}
.step {display:flex; gap:12px; align-items:flex-start; margin-bottom:10px;}
.step .n {min-width:26px; height:26px; border-radius:50%; background:#232852; color:#B9B0FF; font-weight:700;
  display:flex; align-items:center; justify-content:center; font-size:.8rem;}
</style>
"""


LOGO_MARK = """
<svg width="24" height="24" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="15" cy="17" r="10.5" stroke="#F4F6FF" stroke-width="2.6"/>
  <rect x="16.5" y="15.5" width="18" height="18" rx="5.5" stroke="#38BDF8" stroke-width="2.6"/>
</svg>
"""


def inject_css():
    st.markdown(CSS, unsafe_allow_html=True)


def page_header(icon: str, title: str, subtitle: str = ""):
    st.markdown(f"## :material/{icon}: {title}")
    if subtitle:
        st.caption(subtitle)


def badge(text: str, tone: str = "info") -> str:
    c = TONES.get(tone, TONES["info"])
    return f'<span class="badge" style="background:{c}22;color:{c};border:1px solid {c}55">{text}</span>'


def style(fig: go.Figure, height: int = 380, legend: bool = True) -> go.Figure:
    fig.update_layout(
        height=height, colorway=PALETTE, template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=40, b=10), showlegend=legend,
        font=dict(color="#C9CEEA"), legend=dict(orientation="h", y=1.12, x=0),
        hoverlabel=dict(bgcolor="#1B2040"),
    )
    fig.update_xaxes(gridcolor="#20254A", zeroline=False)
    fig.update_yaxes(gridcolor="#20254A", zeroline=False)
    return fig


def plot(fig: go.Figure, height: int = 380, legend: bool = True, key: str | None = None):
    st.plotly_chart(style(fig, height, legend), width="stretch", key=key)


def ctx():
    """Return (df, meta, bundle, quality) or stop the page with a friendly prompt."""
    s = st.session_state
    if not s.get("ready"):
        st.info("Load a dataset first. Open the Dataset page from the sidebar.")
        st.stop()
    return s["df"], s["meta"], s["bundle"], s["quality"]


def fmt(v: float, unit: str = "") -> str:
    a = abs(v)
    s = f"{v:,.0f}" if a >= 1000 else f"{v:,.2f}"
    return f"{s} {unit}".strip()


def get_forecast(horizon: int):
    """Cached per dataset + horizon so pages don't retrain on every rerun."""
    from core.modeling import forecast_target
    s = st.session_state
    key = ("fc", s["ds_id"], horizon)
    if s.get("_fc_key") != key:
        try:
            s["_fc"] = forecast_target(s["df"], s["meta"], horizon)
        except ValueError as exc:
            s["_fc"] = {"error": str(exc)}
        s["_fc_key"] = key
    return s["_fc"]
